const PORTAL_BUTTON_ID = "klear-gmail-rail-button";
const WORK_ICON_SVG = `
  <svg aria-hidden="true" viewBox="0 0 100 111" focusable="false">
    <path
      d="
        M76.9999 88.8457C76.9999 89.9503 76.1045 90.8457 74.9999 90.8457H67.8554C66.7508 90.8457 65.8554 89.9503 65.8554 88.8457V63.7883
        C65.8554 62.5842 64.798 61.6497 63.6127 61.8616C52.1319 63.9144 41.7986 70.4362 35.0097 80.1768L32.6376 83.58
        C32.0061 84.4862 30.7595 84.7088 29.8533 84.0772L24.6446 80.4472C23.7384 79.8157 23.5158 78.5691 24.1473 77.6629L26.5195 74.2588
        C31.3337 67.3515 37.594 61.7571 44.7371 57.7682C46.2313 56.9338 46.2313 54.6541 44.7371 53.8197C37.594 49.831 31.3336 44.2373 26.5195 37.3301
        L24.1473 33.926C23.5158 33.0198 23.7384 31.7732 24.6446 31.1417L29.8533 27.5116C30.7595 26.8801 32.0061 27.1027 32.6376 28.0088L35.0097 31.4121
        C41.7986 41.1526 52.1319 47.6735 63.6126 49.7263C64.798 49.9382 65.8554 49.0037 65.8554 47.7995V22C65.8554 20.8954 66.7508 20 67.8554 20
        H74.9999C76.1045 20 76.9999 20.8954 76.9999 22V88.8457Z
      "
      fill="currentColor"
    />
  </svg>
`;
const PORTAL_BUTTON_VERSION = "10";
const PORTAL_OVERLAY_ID = "klear-gmail-main-overlay";
const PORTAL_BOOT_KEY = "__klearGmailPocController";
const FOCUS_TAB_CACHE_KEY = "__klearFocusTabCache";
const GOOGLE_WORKSPACE_ADMIN_SUBJECT_MISSING = "Google Workspace admin subject is missing";
const GOOGLE_WORKSPACE_GMAIL_SCOPE_MISSING = "Google Workspace Gmail scope is not configured";
const PORTAL_OVERLAY_RAIL_GAP_PX = 10;
const PORTAL_INSIGHTS_HASH_RE =
  /^#klear\/insights(?:\/(?:meeting\/([^/?#]+)|person\/([^/?#]+)|conversation\/([^/?#]+)|contact\/([^/?#]+)\/([^/?#]+)))?\/?$/;
/** Shared with gmail-portal-hash-boot.js (MAIN world). Cleared only on intentional leave. */
const PORTAL_STICKY_HASH_KEY = "klear-gmail-sticky-hash";
const PORTAL_HASH_RESTORE_WINDOW_MS = 15000;
const PORTAL_HASH_RESTORE_POLL_MS = 50;
const RUNTIME_MESSAGE_TIMEOUT_MS = 15_000;
const FOCUS_PORTAL_REQUEST_TIMEOUT_MS = 10_000;
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Elements whose selected-pill background we cleared while Insights is open. */
let clearedRailSelectionNodes = [];

const PORTAL_OVERLAY_STYLES = `
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  :host {
    color: #202124;
    font-family: "Google Sans", Roboto, Arial, sans-serif;
  }

  .klear-insights-shell {
    display: flex;
    height: 100%;
    min-height: 0;
    width: 100%;
  }

  .klear-insights-sidebar {
    background: #fff;
    border-right: 1px solid #e8eaed;
    display: flex;
    flex: 0 0 300px;
    flex-direction: column;
    min-height: 0;
    min-width: 260px;
    overflow: auto;
    padding: 20px 16px 24px;
  }

  .klear-insights-sidebar-header {
    align-items: center;
    display: flex;
    gap: 12px;
    justify-content: space-between;
    margin-bottom: 18px;
  }

  .klear-insights-sidebar-title {
    font-size: 18px;
    font-weight: 600;
    line-height: 1.25;
    margin: 0;
  }

  .klear-insights-button {
    background: #0b57d0;
    border: 0;
    border-radius: 18px;
    color: #fff;
    cursor: pointer;
    font: inherit;
    font-size: 13px;
    font-weight: 500;
    min-height: 32px;
    padding: 0 14px;
    white-space: nowrap;
  }

  .klear-insights-button:disabled {
    cursor: default;
    opacity: 0.7;
  }

  .klear-insights-button.secondary {
    background: #f1f3f4;
    color: #202124;
  }

  .klear-insights-button.ghost {
    background: transparent;
    color: #0b57d0;
    min-height: auto;
    padding: 0;
  }

  .klear-insights-nav {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-bottom: 20px;
  }

  .klear-insights-nav-item {
    align-items: center;
    background: transparent;
    border: 0;
    border-radius: 20px;
    color: #202124;
    cursor: pointer;
    display: flex;
    font: inherit;
    font-size: 14px;
    font-weight: 500;
    gap: 10px;
    min-height: 40px;
    padding: 0 12px;
    text-align: left;
    width: 100%;
  }

  .klear-insights-nav-item[data-active="true"] {
    background: #d3e3fd;
    color: #041e49;
  }

  .klear-insights-nav-icon {
    align-items: center;
    display: inline-flex;
    height: 20px;
    justify-content: center;
    width: 20px;
  }

  .klear-insights-nav-icon svg {
    display: block;
    height: 20px;
    width: 20px;
  }

  .klear-insights-nav-label {
    flex: 1;
    min-width: 0;
  }

  .klear-insights-badge {
    align-items: center;
    background: #d93025;
    border-radius: 999px;
    color: #fff;
    display: inline-flex;
    font-size: 11px;
    font-weight: 600;
    justify-content: center;
    line-height: 1;
    min-height: 18px;
    min-width: 18px;
    padding: 0 5px;
  }

  .klear-insights-section-label {
    color: #5f6368;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.04em;
    margin: 0 0 10px 4px;
    text-transform: uppercase;
  }

  .klear-insights-meeting-list {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .klear-insights-meeting-item {
    align-items: flex-start;
    background: transparent;
    border: 0;
    border-radius: 12px;
    color: inherit;
    cursor: pointer;
    display: flex;
    font: inherit;
    gap: 10px;
    padding: 10px 8px;
    text-align: left;
    width: 100%;
  }

  .klear-insights-meeting-item:hover,
  .klear-insights-meeting-item[data-active="true"] {
    background: #f1f3f4;
  }

  .klear-insights-meeting-icon {
    align-items: center;
    background: #0b57d0;
    border-radius: 6px;
    color: #fff;
    display: inline-flex;
    flex: 0 0 28px;
    height: 28px;
    justify-content: center;
    margin-top: 1px;
    width: 28px;
  }

  .klear-insights-meeting-icon svg {
    display: block;
    height: 16px;
    width: 16px;
  }

  .klear-insights-meeting-copy {
    min-width: 0;
  }

  .klear-insights-meeting-title {
    font-size: 13px;
    font-weight: 600;
    line-height: 1.3;
    margin: 0;
  }

  .klear-insights-meeting-meta {
    color: #5f6368;
    font-size: 12px;
    line-height: 1.3;
    margin: 3px 0 0;
  }

  .klear-insights-main {
    background: #fff;
    display: flex;
    flex: 1;
    flex-direction: column;
    min-height: 0;
    min-width: 0;
    overflow: auto;
    padding: 24px 32px 32px;
  }

  .klear-insights-main[data-view="home"] {
    background: #f8f9fa;
  }

  .klear-insights-main-header {
    align-items: flex-start;
    display: flex;
    gap: 16px;
    justify-content: space-between;
    margin-bottom: 18px;
  }

  .klear-insights-main-heading {
    min-width: 0;
  }

  .klear-insights-main-title {
    font-size: 22px;
    font-weight: 600;
    line-height: 1.25;
    margin: 0;
  }

  .klear-insights-main-subtitle {
    color: #5f6368;
    font-size: 13px;
    margin: 6px 0 0;
  }

  .klear-insights-main-actions {
    align-items: center;
    display: flex;
    flex: 0 0 auto;
    gap: 14px;
  }

  .klear-insights-edit-calendar {
    align-items: center;
    background: transparent;
    border: 0;
    color: #0b57d0;
    cursor: pointer;
    display: inline-flex;
    font: inherit;
    font-size: 13px;
    font-weight: 500;
    gap: 6px;
    margin: 10px 0 0;
    padding: 0;
    text-decoration: none;
  }

  .klear-insights-edit-calendar:hover {
    text-decoration: underline;
  }

  .klear-insights-edit-calendar.is-disabled,
  .klear-insights-edit-calendar.is-disabled:hover {
    cursor: default;
    opacity: 0.7;
    text-decoration: none;
  }

  .klear-insights-edit-calendar svg {
    display: block;
    height: 14px;
    width: 14px;
  }

  .klear-insights-meta-grid {
    display: grid;
    gap: 28px;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
    margin: 22px 0 28px;
  }

  .klear-insights-meta-title {
    color: #202124;
    font-size: 13px;
    font-weight: 600;
    margin: 0 0 10px;
  }

  .klear-insights-meta-copy {
    color: #5f6368;
    font-size: 13px;
    line-height: 1.45;
    margin: 0;
  }

  .klear-insights-join-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .klear-insights-join-link {
    color: #0b57d0;
    font-size: 13px;
    text-decoration: none;
    word-break: break-all;
  }

  .klear-insights-join-link:hover {
    text-decoration: underline;
  }

  .klear-insights-guest-count {
    color: #5f6368;
    font-size: 12px;
    margin: 0 0 12px;
  }

  .klear-insights-guest-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .klear-insights-guest-expand {
    align-self: flex-start;
    background: transparent;
    border: 0;
    color: #0b57d0;
    cursor: pointer;
    font: inherit;
    font-size: 13px;
    font-weight: 500;
    margin-top: 2px;
    padding: 0;
  }

  .klear-insights-guest-expand:hover {
    text-decoration: underline;
  }

  .klear-insights-guest-row {
    align-items: center;
    display: flex;
    gap: 10px;
    min-width: 0;
  }

  .klear-insights-guest-copy {
    min-width: 0;
  }

  .klear-insights-guest-name {
    font-size: 13px;
    font-weight: 500;
    margin: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .klear-insights-guest-email {
    color: #5f6368;
    font-size: 12px;
    margin: 2px 0 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .klear-insights-subsection-title {
    font-size: 16px;
    font-weight: 600;
    margin: 0 0 12px;
  }

  .klear-insights-avatar.sm {
    flex-basis: 28px;
    font-size: 11px;
    height: 28px;
    width: 28px;
  }

  .klear-insights-auto-add {
    align-items: center;
    color: #3c4043;
    display: inline-flex;
    font-size: 13px;
    gap: 8px;
  }

  .klear-insights-switch {
    appearance: none;
    background: #dadce0;
    border: 0;
    border-radius: 999px;
    cursor: pointer;
    height: 20px;
    position: relative;
    width: 36px;
  }

  .klear-insights-switch::after {
    background: #fff;
    border-radius: 50%;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    content: "";
    height: 16px;
    left: 2px;
    position: absolute;
    top: 2px;
    transition: transform 120ms ease;
    width: 16px;
  }

  .klear-insights-switch[aria-checked="true"] {
    background: #0b57d0;
  }

  .klear-insights-switch[aria-checked="true"]::after {
    transform: translateX(16px);
  }

  .klear-insights-day-group {
    margin-bottom: 22px;
  }

  .klear-insights-day-label {
    color: #3c4043;
    font-size: 13px;
    font-weight: 600;
    margin: 0 0 10px 2px;
  }

  .klear-insights-card-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .klear-insights-card {
    background: #f4f4f5;
    border: 1px solid #e4e4e7;
    border-radius: 12px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 12px 6px 6px;
  }

  .klear-insights-card-header {
    align-items: center;
    display: flex;
    gap: 12px;
    justify-content: space-between;
    min-width: 0;
    padding: 0 6px;
  }

  .klear-insights-card-identity {
    align-items: center;
    display: flex;
    flex: 1;
    flex-wrap: wrap;
    gap: 10px;
    min-width: 0;
  }

  .klear-insights-person-pill {
    align-items: center;
    background: #fff;
    border: 1px solid transparent;
    border-radius: 999px;
    display: inline-flex;
    flex: 0 0 auto;
    font: inherit;
    gap: 8px;
    max-width: 100%;
    min-height: 36px;
    padding: 4px 12px 4px 4px;
    text-align: left;
  }

  button.klear-insights-person-pill {
    cursor: pointer;
  }

  button.klear-insights-person-pill:hover {
    background: #f8faff;
    border-color: #c2d7fc;
  }

  button.klear-insights-person-pill:focus-visible {
    border-color: #0b57d0;
    outline: 2px solid rgba(11, 87, 208, 0.25);
    outline-offset: 1px;
  }

  .klear-insights-wiki-sections {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .klear-insights-wiki-section {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .klear-insights-wiki-section-title {
    color: #18181b;
    font-size: 16px;
    font-weight: 600;
    line-height: 1.35;
    margin: 0;
  }

  .klear-insights-wiki-section-body {
    color: #3c4043;
    font-size: 14px;
    line-height: 1.55;
  }

  .klear-insights-wiki-section-body.klear-insights-card-summary {
    margin: 0;
  }

  .klear-insights-wiki-learn-more {
    color: #0b57d0;
    display: inline-block;
    font-size: 13px;
    font-weight: 500;
    margin-top: 8px;
    text-decoration: underline;
    text-underline-offset: 2px;
  }

  .klear-insights-wiki-learn-more:hover {
    text-decoration: none;
  }

  .klear-insights-avatar {
    align-items: center;
    background: #e8f0fe;
    border-radius: 50%;
    color: #0b57d0;
    display: inline-flex;
    flex: 0 0 28px;
    font-size: 11px;
    font-weight: 600;
    height: 28px;
    justify-content: center;
    width: 28px;
  }

  .klear-insights-card-name {
    color: #18181b;
    font-size: 13px;
    font-weight: 600;
    margin: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .klear-insights-card-meta {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    min-width: 0;
  }

  .klear-insights-card-time {
    color: #71717b;
    font-size: 13px;
    font-weight: 500;
  }

  .klear-insights-card-meeting {
    background: transparent;
    border: 0;
    color: #0b57d0;
    cursor: pointer;
    display: inline;
    font: inherit;
    font-size: 13px;
    font-weight: 500;
    padding: 0;
    text-align: left;
    text-decoration: underline;
    text-underline-offset: 2px;
  }

  .klear-insights-card-meeting:hover {
    text-decoration: none;
  }

  .klear-insights-card-actions {
    align-items: center;
    display: flex;
    flex: 0 0 auto;
    gap: 14px;
  }

  .klear-insights-card-action {
    background: transparent;
    border: 0;
    color: #0b57d0;
    cursor: pointer;
    font: inherit;
    font-size: 13px;
    font-weight: 500;
    padding: 0;
  }

  .klear-insights-card-action.muted {
    color: #71717b;
  }

  .klear-streak-modal-backdrop {
    align-items: center;
    background: rgba(24, 24, 27, 0.45);
    bottom: 0;
    display: flex;
    justify-content: center;
    left: 0;
    padding: 24px;
    position: absolute;
    right: 0;
    top: 0;
    z-index: 40;
  }

  .klear-streak-modal {
    background: #ffffff;
    border: 1px solid #e4e4e7;
    border-radius: 16px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.18);
    display: flex;
    flex-direction: column;
    gap: 16px;
    max-height: min(720px, calc(100% - 32px));
    max-width: 520px;
    overflow: hidden;
    padding: 20px;
    width: 100%;
  }

  .klear-streak-modal-title {
    color: #18181b;
    font-size: 18px;
    font-weight: 600;
    margin: 0;
  }

  .klear-streak-modal-copy {
    color: #52525b;
    font-size: 14px;
    line-height: 1.45;
    margin: 0;
  }

  .klear-streak-modal-label {
    color: #3f3f46;
    display: block;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 6px;
  }

  .klear-streak-modal-select {
    appearance: none;
    background: #f4f4f5;
    border: 1px solid #d4d4d8;
    border-radius: 10px;
    color: #18181b;
    font: inherit;
    font-size: 14px;
    padding: 10px 12px;
    width: 100%;
  }

  .klear-streak-box-list {
    border: 1px solid #e4e4e7;
    border-radius: 12px;
    max-height: 260px;
    overflow: auto;
  }

  .klear-streak-box-item {
    background: #ffffff;
    border: 0;
    border-bottom: 1px solid #e4e4e7;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: 12px 14px;
    text-align: left;
    width: 100%;
  }

  .klear-streak-box-item:last-child {
    border-bottom: 0;
  }

  .klear-streak-box-item[data-selected="true"] {
    background: #eff6ff;
  }

  .klear-streak-box-name {
    color: #18181b;
    font-size: 14px;
    font-weight: 600;
  }

  .klear-streak-box-notes {
    color: #71717b;
    font-size: 12px;
    line-height: 1.35;
  }

  .klear-streak-modal-status {
    color: #71717b;
    font-size: 13px;
    margin: 0;
  }

  .klear-streak-modal-status.error {
    color: #dc2626;
  }

  .klear-streak-modal-checkbox {
    align-items: flex-start;
    color: #3f3f46;
    cursor: pointer;
    display: flex;
    font-size: 14px;
    font-weight: 500;
    gap: 10px;
    line-height: 1.4;
    user-select: none;
  }

  .klear-streak-modal-checkbox input {
    accent-color: #0b57d0;
    flex: 0 0 auto;
    height: 16px;
    margin: 2px 0 0;
    width: 16px;
  }

  .klear-streak-modal-actions {
    display: flex;
    gap: 8px;
    justify-content: flex-end;
  }

  .klear-streak-modal-button {
    background: #ffffff;
    border: 1px solid #a1a1aa;
    border-radius: 10px;
    color: #3f3f46;
    cursor: pointer;
    font: inherit;
    font-size: 14px;
    font-weight: 500;
    padding: 8px 14px;
  }

  .klear-streak-modal-button.primary {
    background: #ea580c;
    border-color: #ea580c;
    color: #ffffff;
  }

  .klear-streak-modal-button:disabled {
    cursor: default;
    opacity: 0.55;
  }

  .klear-insights-card-status {
    color: #71717b;
    flex: 0 0 auto;
    font-size: 13px;
    font-weight: 500;
    white-space: nowrap;
  }

  .klear-insights-card-body {
    background: #fff;
    border-radius: 8px;
    padding: 8px;
    width: 100%;
  }

  .klear-insights-card-summary {
    color: #18181b;
    font-size: 13px;
    font-weight: 500;
    line-height: 1.5;
    margin: 0;
  }

  .klear-insights-card-summary[data-format="plain"] {
    display: -webkit-box;
    overflow: hidden;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 5;
  }

  .klear-insights-card-summary[data-format="markdown"] > :first-child {
    margin-top: 0;
  }

  .klear-insights-card-summary[data-format="markdown"] > :last-child {
    margin-bottom: 0;
  }

  .klear-insights-card-summary[data-format="markdown"] p,
  .klear-insights-card-summary[data-format="markdown"] ul,
  .klear-insights-card-summary[data-format="markdown"] ol,
  .klear-insights-card-summary[data-format="markdown"] pre,
  .klear-insights-card-summary[data-format="markdown"] blockquote {
    margin: 0 0 0.75em;
  }

  .klear-insights-card-summary[data-format="markdown"] h1,
  .klear-insights-card-summary[data-format="markdown"] h2,
  .klear-insights-card-summary[data-format="markdown"] h3,
  .klear-insights-card-summary[data-format="markdown"] h4 {
    color: #202124;
    font-size: 14px;
    font-weight: 600;
    line-height: 1.35;
    margin: 0 0 0.55em;
  }

  .klear-insights-card-summary[data-format="markdown"] ul,
  .klear-insights-card-summary[data-format="markdown"] ol {
    padding-left: 1.25em;
  }

  .klear-insights-card-summary[data-format="markdown"] li {
    margin: 0.2em 0;
  }

  .klear-insights-card-summary[data-format="markdown"] a {
    color: #0b57d0;
    text-decoration: underline;
    text-underline-offset: 2px;
  }

  .klear-insights-card-summary[data-format="markdown"] code {
    background: #f1f3f4;
    border-radius: 4px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 12px;
    padding: 0.1em 0.35em;
  }

  .klear-insights-card-summary[data-format="markdown"] pre {
    background: #f1f3f4;
    border-radius: 8px;
    overflow: auto;
    padding: 10px 12px;
  }

  .klear-insights-card-summary[data-format="markdown"] pre code {
    background: transparent;
    padding: 0;
  }

  .klear-insights-card-summary[data-format="markdown"] blockquote {
    border-left: 3px solid #dadce0;
    color: #5f6368;
    padding-left: 12px;
  }

  .klear-insights-card-summary[data-format="markdown"] strong {
    font-weight: 600;
  }

  .klear-insights-status,
  .klear-insights-empty {
    color: #5f6368;
    font-size: 14px;
    padding: 18px 0;
  }

  .klear-focus-loading {
    align-items: center;
    background: #fff;
    display: flex;
    flex: 1 1 auto;
    justify-content: center;
    min-height: 100%;
    padding: 32px;
    width: 100%;
  }

  .klear-focus-loading-card {
    align-items: center;
    display: flex;
    flex-direction: column;
    max-width: 320px;
    text-align: center;
  }

  .klear-focus-loading-mark {
    align-items: center;
    display: flex;
    height: 42px;
    justify-content: center;
    margin-bottom: 18px;
    width: 42px;
  }

  .klear-focus-loading-mark svg {
    color: #3c4043;
    display: block;
    height: 42px;
    width: 38px;
  }

  .klear-focus-loading-title {
    color: #202124;
    font-size: 18px;
    font-weight: 600;
    margin: 0;
  }

  .klear-focus-loading-copy {
    color: #5f6368;
    font-size: 14px;
    line-height: 1.45;
    margin: 7px 0 0;
  }

  .klear-focus-loading-bar {
    background: #e8eaed;
    border-radius: 999px;
    height: 3px;
    margin-top: 20px;
    overflow: hidden;
    width: 116px;
  }

  .klear-focus-loading-bar::after {
    animation: klear-focus-loading 1.1s ease-in-out infinite;
    background: #5f6368;
    border-radius: inherit;
    content: "";
    display: block;
    height: 100%;
    width: 42%;
  }

  @keyframes klear-focus-loading {
    0% { transform: translateX(-110%); }
    100% { transform: translateX(270%); }
  }

  .klear-focus-error {
    align-items: center;
    background: #fff;
    display: flex;
    flex: 1 1 auto;
    justify-content: center;
    min-height: 100%;
    padding: 32px;
    width: 100%;
  }

  .klear-focus-error-card {
    align-items: center;
    display: flex;
    flex-direction: column;
    max-width: 380px;
    text-align: center;
  }

  .klear-focus-error-mark {
    align-items: center;
    background: #fce8e6;
    border-radius: 50%;
    color: #b3261e;
    display: flex;
    font-size: 22px;
    font-weight: 600;
    height: 42px;
    justify-content: center;
    margin-bottom: 18px;
    width: 42px;
  }

  .klear-focus-error-title {
    color: #202124;
    font-size: 18px;
    font-weight: 600;
    margin: 0;
  }

  .klear-focus-error-copy {
    color: #5f6368;
    font-size: 14px;
    line-height: 1.5;
    margin: 8px 0 0;
  }

  .klear-focus-workspace-field {
    color: #3c4043;
    display: flex;
    flex-direction: column;
    font-size: 13px;
    font-weight: 500;
    gap: 6px;
    margin-top: 20px;
    text-align: left;
    width: 100%;
  }

  .klear-focus-workspace-select {
    background: #fff;
    border: 1px solid #dadce0;
    border-radius: 6px;
    color: #202124;
    cursor: pointer;
    font: inherit;
    font-weight: 400;
    min-height: 40px;
    padding: 0 12px;
    width: 100%;
  }

  .klear-focus-workspace-select:focus {
    border-color: #1a73e8;
    box-shadow: 0 0 0 1px #1a73e8;
    outline: 0;
  }

  .klear-focus-error-retry {
    background: #1a73e8;
    border: 0;
    border-radius: 999px;
    color: #fff;
    cursor: pointer;
    font: inherit;
    font-size: 14px;
    font-weight: 500;
    margin-top: 20px;
    padding: 9px 16px;
  }

  .klear-focus-error-retry:hover { background: #185abc; }

  .klear-focus-error-integrations {
    background: transparent;
    border: 0;
    color: #1a73e8;
    cursor: pointer;
    font: inherit;
    font-size: 14px;
    font-weight: 500;
    margin-top: 12px;
    padding: 4px;
  }

  .klear-focus-error-integrations:hover { text-decoration: underline; }

  .klear-insights-error {
    background: #fce8e6;
    border-radius: 8px;
    color: #b3261e;
    font-size: 14px;
    padding: 12px 14px;
  }

  .klear-insights-auth-required {
    align-items: center;
    background: #fff;
    display: flex;
    flex: 1 1 auto;
    justify-content: center;
    min-height: 100%;
    padding: 32px;
    width: 100%;
  }

  .klear-insights-auth-card {
    align-items: center;
    background: #fff;
    border: 1px solid #e1e1e1;
    border-radius: 18px;
    box-shadow: 0 12px 32px rgba(60, 64, 67, 0.08);
    display: flex;
    flex-direction: column;
    max-width: 440px;
    padding: 34px 38px;
    text-align: center;
    width: 100%;
  }

  .klear-insights-auth-mark {
    align-items: center;
    color: #3c4043;
    display: flex;
    height: 42px;
    justify-content: center;
    margin-bottom: 18px;
    width: 42px;
  }

  .klear-insights-auth-mark svg {
    display: block;
    height: 42px;
    width: 38px;
  }

  .klear-insights-auth-title {
    font-size: 16px;
    font-weight: 600;
    margin: 0 0 7px;
  }

  .klear-insights-auth-copy {
    color: #5f6368;
    font-size: 14px;
    line-height: 1.45;
    margin: 0 0 20px;
  }
`;

window[PORTAL_BOOT_KEY]?.teardown?.();

const controller = new AbortController();
let railEnsureTimer = null;
let routeCheckTimer = null;
let observer = null;
let lastLocation = window.location.href;
let selectedMeetingId = null;
let selectedPersonKey = null;
let selectedFocusConversationId = null;
let selectedFocusContactName = null;
let refreshInsightsView = null;
let lastNonPortalHash = "#inbox";

// Focus data stays only in this content script's memory. It makes back/forward navigation
// instant without persisting Gmail-derived data to extension storage or disk.
const focusTabCache = window[FOCUS_TAB_CACHE_KEY] ?? {
  contactAnalyses: new Map(),
  contactRouteAnalyses: new Map(),
  conversations: null,
  ownerUserId: null,
  threadAnalyses: new Map(),
};
if (!(focusTabCache.contactRouteAnalyses instanceof Map)) {
  focusTabCache.contactRouteAnalyses = new Map();
}
window[FOCUS_TAB_CACHE_KEY] = focusTabCache;

const resetFocusTabCacheForOwner = (ownerUserId) => {
  if (focusTabCache.ownerUserId === ownerUserId) {
    return;
  }

  focusTabCache.contactAnalyses.clear();
  focusTabCache.contactRouteAnalyses.clear();
  focusTabCache.conversations = null;
  focusTabCache.ownerUserId = ownerUserId;
  focusTabCache.threadAnalyses.clear();
};

const getCachedFocusRequest = (cache, key, request) => {
  const cachedRequest = cache.get(key);
  if (cachedRequest) {
    return cachedRequest;
  }

  const requestPromise = request();
  cache.set(key, requestPromise);
  void requestPromise.catch(() => {
    if (cache.get(key) === requestPromise) {
      cache.delete(key);
    }
  });
  return requestPromise;
};

const getFocusContactRouteCacheKey = (conversationId, contactName) => {
  if (!conversationId || !contactName) {
    return "";
  }

  return `${conversationId}:${contactName.trim().toLowerCase()}`;
};

const hasCachedFocusRoute = () => {
  if (!focusTabCache.conversations) {
    return false;
  }

  if (!selectedFocusConversationId) {
    return true;
  }

  if (!selectedFocusContactName) {
    return focusTabCache.threadAnalyses.has(selectedFocusConversationId);
  }

  return focusTabCache.contactRouteAnalyses.has(
    getFocusContactRouteCacheKey(selectedFocusConversationId, selectedFocusContactName),
  );
};

const parsePortalRoute = () => {
  const match = window.location.hash.match(PORTAL_INSIGHTS_HASH_RE);
  if (!match) {
    return null;
  }

  const rawMeetingId = match[1];
  const rawPersonKey = match[2];
  const rawFocusConversationId = match[3];
  const rawFocusContactName = match[4];
  const rawFocusContactConversationId = match[5];

  let meetingId = null;
  if (rawMeetingId) {
    try {
      meetingId = decodeURIComponent(rawMeetingId);
    } catch {
      meetingId = rawMeetingId;
    }
  }

  let personKey = null;
  if (rawPersonKey) {
    try {
      personKey = decodeURIComponent(rawPersonKey);
    } catch {
      personKey = rawPersonKey;
    }
  }

  const decodeRouteSegment = (value) => {
    if (!value) {
      return null;
    }

    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  };
  const focusConversationId = decodeRouteSegment(rawFocusConversationId);
  const focusContactName = decodeRouteSegment(rawFocusContactName);
  const focusContactConversationId = decodeRouteSegment(rawFocusContactConversationId);

  return { meetingId, personKey, focusConversationId, focusContactName, focusContactConversationId };
};

const buildPortalHash = ({ meetingId = null, personKey = null, focusConversationId = null, focusContactName = null } = {}) => {
  if (typeof focusContactName === "string" && focusContactName && typeof focusConversationId === "string" && focusConversationId) {
    return `#klear/insights/contact/${encodeURIComponent(focusContactName)}/${encodeURIComponent(focusConversationId)}`;
  }

  if (typeof focusConversationId === "string" && focusConversationId) {
    return `#klear/insights/conversation/${encodeURIComponent(focusConversationId)}`;
  }

  if (typeof personKey === "string" && personKey) {
    return `#klear/insights/person/${encodeURIComponent(personKey)}`;
  }

  if (typeof meetingId === "string" && meetingId) {
    return `#klear/insights/meeting/${encodeURIComponent(meetingId)}`;
  }

  return "#klear/insights";
};

const readStickyPortalHash = () => {
  try {
    const hash = sessionStorage.getItem(PORTAL_STICKY_HASH_KEY);
    return typeof hash === "string" && PORTAL_INSIGHTS_HASH_RE.test(hash) ? hash : null;
  } catch {
    return null;
  }
};

const sendRuntimeMessageSafely = (message, callback = null) => {
  try {
    if (!chrome.runtime?.id) {
      return false;
    }

    chrome.runtime.sendMessage(message, callback ?? undefined);
    return true;
  } catch {
    return false;
  }
};

const rememberPortalHash = (hash) => {
  if (typeof hash !== "string" || !PORTAL_INSIGHTS_HASH_RE.test(hash)) {
    return;
  }

  try {
    sessionStorage.setItem(PORTAL_STICKY_HASH_KEY, hash);
  } catch {
    // ignore
  }

  sendRuntimeMessageSafely({ type: "remember-portal-hash", hash }, () => {
    try {
      void chrome.runtime.lastError;
    } catch {
      // The extension was reloaded before the response callback ran.
    }
  });
};

const clearStickyPortalHash = () => {
  try {
    sessionStorage.removeItem(PORTAL_STICKY_HASH_KEY);
  } catch {
    // ignore
  }

  sendRuntimeMessageSafely({ type: "clear-portal-hash" }, () => {
    try {
      void chrome.runtime.lastError;
    } catch {
      // The extension was reloaded before the response callback ran.
    }
  });
};

const fetchBackgroundPortalHash = () =>
  new Promise((resolve) => {
    const sent = sendRuntimeMessageSafely({ type: "get-portal-hash" }, (result) => {
      try {
        void chrome.runtime.lastError;
      } catch {
        resolve(null);
        return;
      }
      const hash = typeof result?.hash === "string" ? result.hash : null;
      resolve(hash && PORTAL_INSIGHTS_HASH_RE.test(hash) ? hash : null);
    });

    if (!sent) {
      resolve(null);
    }
  });

const resolvePortalHashToRestore = async () => {
  if (parsePortalRoute()) {
    return window.location.hash;
  }

  const stickyHash = readStickyPortalHash();
  if (stickyHash) {
    return stickyHash;
  }

  return fetchBackgroundPortalHash();
};

const setLocationHash = (hash, { replace = false } = {}) => {
  const nextUrl = `${window.location.pathname}${window.location.search}${hash}`;

  if (PORTAL_INSIGHTS_HASH_RE.test(hash)) {
    rememberPortalHash(hash);
  }

  if (replace) {
    history.replaceState(null, "", nextUrl);
    lastLocation = window.location.href;
    syncInsightsFromLocation();
    return;
  }

  if (window.location.hash === hash) {
    syncInsightsFromLocation();
    return;
  }

  // Gmail replaces unfamiliar hashes with #inbox. A direct history entry makes the
  // Focus route durable, so Back returns to the selected Focus screen rather than
  // to the Inbox route Gmail temporarily substitutes.
  history.pushState({ klearFocusRoute: true }, "", nextUrl);
  lastLocation = window.location.href;
  syncInsightsFromLocation();
};

/**
 * Re-open Insights from sticky state even when Gmail has already forced `#inbox`.
 * Also keeps fighting the hash so the URL bar can catch up when possible.
 *
 * Sticky is the session flag: set while Insights is open, cleared only by
 * leavePortalRoute (rail click, Inbox/Sent, Back, etc.). Never clear sticky just
 * because Gmail temporarily rewrote the hash to `#inbox` during boot.
 */
const restorePortalHashAfterGmailBoot = async (seedHash = null) => {
  const pendingHash = typeof seedHash === "string" && PORTAL_INSIGHTS_HASH_RE.test(seedHash) ? seedHash : await resolvePortalHashToRestore();

  if (!pendingHash) {
    return false;
  }

  // User already left while we were resolving.
  if (!readStickyPortalHash()) {
    return false;
  }

  rememberPortalHash(pendingHash);

  if (window.location.hash !== pendingHash) {
    const nextUrl = `${window.location.pathname}${window.location.search}${pendingHash}`;
    history.replaceState(null, "", nextUrl);
    lastLocation = window.location.href;
  }

  const startedAt = Date.now();
  let stableSince = null;

  while (Date.now() - startedAt < PORTAL_HASH_RESTORE_WINDOW_MS) {
    if (controller.signal.aborted) {
      return false;
    }

    // User left Insights (Inbox, Sent, etc.) — stop restore immediately.
    if (!readStickyPortalHash()) {
      return false;
    }

    if (window.location.hash !== pendingHash) {
      stableSince = null;
      const nextUrl = `${window.location.pathname}${window.location.search}${pendingHash}`;
      history.replaceState(null, "", nextUrl);
      lastLocation = window.location.href;
    } else if (stableSince === null) {
      stableSince = Date.now();
    } else if (Date.now() - stableSince >= 400) {
      return true;
    }

    await wait(PORTAL_HASH_RESTORE_POLL_MS);
  }

  return Boolean(readStickyPortalHash());
};

const navigatePortalRoute = (target = null, { replace = false } = {}) => {
  if (typeof target === "string" || target === null || target === undefined) {
    setLocationHash(buildPortalHash({ meetingId: target ?? null }), { replace });
    return;
  }

  setLocationHash(
    buildPortalHash({
      meetingId: typeof target.meetingId === "string" ? target.meetingId : null,
      personKey: typeof target.personKey === "string" ? target.personKey : null,
      focusConversationId: typeof target.focusConversationId === "string" ? target.focusConversationId : null,
      focusContactName: typeof target.focusContactName === "string" ? target.focusContactName : null,
    }),
    { replace },
  );
};

const leavePortalRoute = () => {
  clearStickyPortalHash();

  if (!parsePortalRoute()) {
    unmountPortalInsights();
    return;
  }

  const fallbackHash = lastNonPortalHash && !PORTAL_INSIGHTS_HASH_RE.test(lastNonPortalHash) ? lastNonPortalHash : "#inbox";
  setLocationHash(fallbackHash, { replace: true });
};

const markPortalHashForNextLoad = () => {
  const stickyHash = parsePortalRoute() ? window.location.hash : readStickyPortalHash();
  if (!stickyHash) {
    return;
  }

  rememberPortalHash(stickyHash);
};

const parsePortalHashString = (hash) => {
  const match = hash.match(PORTAL_INSIGHTS_HASH_RE);
  if (!match) {
    return null;
  }

  const rawMeetingId = match[1];
  const rawPersonKey = match[2];
  const rawFocusConversationId = match[3];
  const rawFocusContactName = match[4];
  const rawFocusContactConversationId = match[5];

  let meetingId = null;
  if (rawMeetingId) {
    try {
      meetingId = decodeURIComponent(rawMeetingId);
    } catch {
      meetingId = rawMeetingId;
    }
  }

  let personKey = null;
  if (rawPersonKey) {
    try {
      personKey = decodeURIComponent(rawPersonKey);
    } catch {
      personKey = rawPersonKey;
    }
  }

  const decodeRouteSegment = (value) => {
    if (!value) {
      return null;
    }

    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  };
  const focusConversationId = decodeRouteSegment(rawFocusConversationId);
  const focusContactName = decodeRouteSegment(rawFocusContactName);
  const focusContactConversationId = decodeRouteSegment(rawFocusContactConversationId);

  return { meetingId, personKey, focusConversationId, focusContactName, focusContactConversationId };
};

window[PORTAL_BOOT_KEY] = {
  teardown: () => {
    controller.abort();

    if (railEnsureTimer !== null) {
      window.clearTimeout(railEnsureTimer);
      railEnsureTimer = null;
    }

    if (routeCheckTimer !== null) {
      window.clearInterval(routeCheckTimer);
      routeCheckTimer = null;
    }

    observer?.disconnect();
    observer = null;
    document.getElementById(PORTAL_BUTTON_ID)?.remove();
    document.getElementById(PORTAL_OVERLAY_ID)?.remove();
  },
};

const sendRuntimeMessage = (message, timeoutMs = RUNTIME_MESSAGE_TIMEOUT_MS) =>
  new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => {
      reject(new Error("Focus could not reach the Portal extension service. Refresh Gmail and try again."));
    }, timeoutMs);
    const sent = sendRuntimeMessageSafely(message, (response) => {
      window.clearTimeout(timeoutId);
      let lastError = null;
      try {
        lastError = chrome.runtime.lastError;
      } catch {
        reject(new Error("Extension reloaded. Refresh Gmail and try again."));
        return;
      }
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }

      if (!response?.ok) {
        const error = new Error(response?.error ?? "Extension request failed");
        error.code = response?.code;
        reject(error);
        return;
      }

      resolve(response.result);
    });

    if (!sent) {
      window.clearTimeout(timeoutId);
      reject(new Error("Extension reloaded. Refresh Gmail and try again."));
    }
  });

const readExtensionStorage = (keys) =>
  new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get(keys, (result) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(lastError.message));
          return;
        }
        resolve(result);
      });
    } catch {
      reject(new Error("Extension storage is unavailable."));
    }
  });

const getStoredWorkspaces = (stored) => {
  const workspaces = stored?.user?.workspaces;
  if (!Array.isArray(workspaces)) {
    return [];
  }

  return workspaces.filter((workspace) => typeof workspace?.ownerUserId === "string" && workspace.ownerUserId);
};

const getStoredOwnerUserId = (stored) => {
  const workspaces = getStoredWorkspaces(stored);
  const selectedOwnerUserId = stored?.[SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY];
  if (
    typeof selectedOwnerUserId === "string" &&
    workspaces.some((workspace) => workspace.ownerUserId === selectedOwnerUserId)
  ) {
    return selectedOwnerUserId;
  }

  if (workspaces.length === 1) {
    return workspaces[0].ownerUserId;
  }

  // Extensions connected to an older Portal deployment do not receive workspace
  // data yet. Keep the legacy fallback only for that short compatibility window.
  if (stored?.user && !Array.isArray(stored.user.workspaces)) {
    const ownerUserId = stored.user.ownerUserId;
    return typeof ownerUserId === "string" && ownerUserId ? ownerUserId : stored.user.id ?? "";
  }

  return "";
};

const createFocusRequestError = (message, code = "request_failed") => {
  const error = new Error(message);
  error.code = code;
  return error;
};

const fetchFocusPortalJson = async (path, { method = "GET", body = null, allowNotFound = false } = {}) => {
  const stored = await readExtensionStorage(["apiToken", APP_URL_STORAGE_KEY, "user", SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]);
  const token = typeof stored?.apiToken === "string" ? stored.apiToken : "";
  const ownerUserId = getStoredOwnerUserId(stored);
  if (!token) {
    throw createFocusRequestError("Sign in to Portal to load Focus.", "auth_required");
  }
  if (!ownerUserId) {
    throw createFocusRequestError("Choose the workspace Klear should connect to.", "workspace_required");
  }

  const storedAppUrl = stored?.[APP_URL_STORAGE_KEY];
  const appUrl = typeof storedAppUrl === "string" && storedAppUrl ? storedAppUrl : DEFAULT_PORTAL_APP_URL;
  const appUrls = [appUrl];
  try {
    const parsedAppUrl = new URL(appUrl);
    if (parsedAppUrl.hostname === "localhost" && parsedAppUrl.port !== "3000") {
      parsedAppUrl.port = "3000";
      appUrls.push(parsedAppUrl.origin);
    }
  } catch {
    // The configured URL below will surface a clear connection error.
  }

  let response = null;
  let resolvedAppUrl = appUrl;
  for (const candidateAppUrl of appUrls) {
    const abortController = new AbortController();
    const timeoutId = window.setTimeout(() => abortController.abort(), FOCUS_PORTAL_REQUEST_TIMEOUT_MS);
    try {
      response = await fetch(`${candidateAppUrl}${path}`, {
        method,
        headers: {
          Authorization: `Bearer ${token}`,
          ...(body ? { "Content-Type": "application/json" } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: abortController.signal,
      });
      resolvedAppUrl = candidateAppUrl;
      break;
    } catch {
      // A stale localhost port is common in local extension development. Try the
      // current Portal development default before showing a connection error.
    } finally {
      window.clearTimeout(timeoutId);
    }
  }

  if (!response) {
    throw createFocusRequestError(`Could not reach Portal at ${appUrl}.`);
  }

  if (resolvedAppUrl !== appUrl) {
    void chrome.storage.local.set({ [APP_URL_STORAGE_KEY]: resolvedAppUrl });
  }

  if (response.status === 404 && allowNotFound) {
    return null;
  }

  const responseText = await response.text();
  let payload = null;
  try {
    payload = responseText ? JSON.parse(responseText) : null;
  } catch {
    // Keep the text fallback below.
  }

  if (!response.ok) {
    const message = typeof payload?.error === "string" ? payload.error : responseText || `Portal request failed (${response.status}).`;
    throw createFocusRequestError(message, response.status === 401 || response.status === 403 ? "auth_required" : "request_failed");
  }

  return payload;
};

const sendFocusMessage = async (message) => {
  const stored = await readExtensionStorage(["user", SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]);
  const ownerUserId = getStoredOwnerUserId(stored);
  if (!ownerUserId) {
    if (stored?.user?.id) {
      throw createFocusRequestError("Choose the workspace Klear should connect to.", "workspace_required");
    }
    throw createFocusRequestError("Sign in to Portal to load Focus.", "auth_required");
  }

  resetFocusTabCacheForOwner(ownerUserId);

  if (message?.type === "fetch-focus-conversations") {
    if (focusTabCache.conversations) {
      return focusTabCache.conversations;
    }

    const params = new URLSearchParams({ owner_user_id: ownerUserId, limit: "20" });
    const requestPromise = fetchFocusPortalJson(`/api/google-workspace-admin/gmail-conversations?${params.toString()}`);
    focusTabCache.conversations = requestPromise;
    void requestPromise.catch(() => {
      if (focusTabCache.conversations === requestPromise) {
        focusTabCache.conversations = null;
      }
    });
    return requestPromise;
  }

  if (message?.type === "fetch-focus-analysis") {
    const threadId = typeof message.threadId === "string" ? message.threadId : "";
    const path = `/api/google-workspace-admin/gmail-threads/${encodeURIComponent(threadId)}`;
    return getCachedFocusRequest(focusTabCache.threadAnalyses, threadId, async () => {
      const params = new URLSearchParams({ owner_user_id: ownerUserId });
      const existing = await fetchFocusPortalJson(`${path}/analysis?${params.toString()}`, { allowNotFound: true });
      return existing ?? fetchFocusPortalJson(`${path}/analyze`, {
        method: "POST",
        body: { owner_user_id: ownerUserId, force: false },
      });
    });
  }

  if (message?.type === "fetch-focus-contact-analysis") {
    const email = typeof message.email === "string" ? message.email.trim().toLowerCase() : "";
    const path = `/api/google-workspace-admin/contacts/${encodeURIComponent(email)}`;
    return getCachedFocusRequest(focusTabCache.contactAnalyses, email, async () => {
      const params = new URLSearchParams({ owner_user_id: ownerUserId });
      const existing = await fetchFocusPortalJson(`${path}/analysis?${params.toString()}`, { allowNotFound: true });
      return existing ?? fetchFocusPortalJson(`${path}/analyze`, {
        method: "POST",
        body: { owner_user_id: ownerUserId, force: false },
      });
    });
  }

  throw createFocusRequestError("Unsupported Focus request.");
};

const getGmailAppRail = () => {
  const railCandidates = Array.from(document.querySelectorAll('div[role="navigation"]'));
  return (
    railCandidates.find((candidate) => {
      const headings = Array.from(candidate.querySelectorAll('[role="heading"]')).map((heading) => heading.textContent?.trim());
      return headings.includes("Mail") && headings.includes("Chat") && headings.includes("Meet");
    }) ?? null
  );
};

const getMeetRailItem = (rail) =>
  Array.from(rail.children).find((child) => {
    if (!(child instanceof HTMLElement)) {
      return false;
    }

    const heading = child.querySelector('[role="heading"]');
    return heading?.textContent?.trim() === "Meet";
  }) ?? null;

const getGmailInboxItem = () => {
  const inboxLink = Array.from(document.querySelectorAll('a[href*="#inbox"]')).find((candidate) => {
    if (!(candidate instanceof HTMLAnchorElement)) {
      return false;
    }

    return candidate.closest("[data-tooltip]") !== null;
  });

  return inboxLink?.closest("[data-tooltip]") ?? null;
};

const getGmailNavigation = () => {
  const appRail = getGmailAppRail();
  if (appRail) {
    return appRail;
  }

  return getGmailInboxItem()?.closest('div[role="navigation"]') ?? null;
};

const getGmailHeaderBottom = () => {
  const candidates = Array.from(document.querySelectorAll('header, [role="banner"]'));
  const header = candidates.find((candidate) => {
    if (!(candidate instanceof HTMLElement)) {
      return false;
    }

    const rect = candidate.getBoundingClientRect();
    return rect.top <= 16 && rect.height >= 40 && rect.height <= 96 && rect.width >= window.innerWidth * 0.4;
  });

  if (!header) {
    return 64;
  }

  return Math.round(header.getBoundingClientRect().bottom);
};

const updateOverlayBounds = (overlay = document.getElementById(PORTAL_OVERLAY_ID)) => {
  if (!(overlay instanceof HTMLElement)) {
    return;
  }

  const rail = getGmailAppRail();
  const sidebar = getGmailInboxItem();
  const navigation = rail instanceof HTMLElement ? rail : sidebar;
  const navigationRight = navigation instanceof HTMLElement ? Math.round(navigation.getBoundingClientRect().right) : 0;

  overlay.style.setProperty("--klear-gmail-overlay-left", `${Math.max(0, navigationRight + PORTAL_OVERLAY_RAIL_GAP_PX)}px`);
  overlay.style.setProperty("--klear-gmail-overlay-top", `${Math.max(0, getGmailHeaderBottom())}px`);
};

const clearElement = (element) => {
  while (element.firstChild) {
    element.firstChild.remove();
  }
};

const appendText = (parent, tagName, className, text) => {
  const element = document.createElement(tagName);
  element.className = className;
  element.textContent = text;
  parent.appendChild(element);
  return element;
};

const parseJobDate = (value) => {
  if (typeof value !== "string" || !value.trim()) {
    return null;
  }

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const getJobDateValue = (job) => parseJobDate(job?.data_date) ?? parseJobDate(job?.created_at);

const getJobTitle = (job) => {
  if (typeof job?.title === "string" && job.title.trim()) {
    return job.title.trim();
  }

  if (typeof job?.summary === "string" && job.summary.trim()) {
    return job.summary.trim().slice(0, 80);
  }

  if (typeof job?.source_type === "string" && job.source_type.trim()) {
    return `${job.source_type.trim()} meeting`;
  }

  return "Untitled meeting";
};

const getJobSummary = (job) => {
  if (typeof job?.summary === "string" && job.summary.trim()) {
    const summary = job.summary.trim();
    if (!summary.toLowerCase().endsWith("no summary created")) {
      return summary;
    }
  }

  if (typeof job?.summary_preview === "string" && job.summary_preview.trim()) {
    return job.summary_preview.trim();
  }

  return "";
};

const DEFAULT_PORTAL_APP_URL = "https://app.internode.ai";
const APP_URL_STORAGE_KEY = "appUrl:app.internode.ai";
const SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY = "selectedWorkspaceOwnerUserId";
let portalAppUrl = DEFAULT_PORTAL_APP_URL;

const normalizePortalAppUrl = (value) => {
  if (typeof value !== "string" || !value.trim()) {
    return DEFAULT_PORTAL_APP_URL;
  }

  return value.trim().replace(/\/+$/, "");
};

const _refreshPortalAppUrl = async () => {
  try {
    const stored = await chrome.storage.local.get([APP_URL_STORAGE_KEY]);
    portalAppUrl = normalizePortalAppUrl(stored[APP_URL_STORAGE_KEY]);
  } catch {
    portalAppUrl = DEFAULT_PORTAL_APP_URL;
  }

  return portalAppUrl;
};

/** Resolve markdown hrefs against the Portal app origin (extension appUrl / NEXTAUTH_URL). */
const resolvePortalMarkdownHref = (rawHref) => {
  const href = decodeHtmlEntities(String(rawHref ?? "").trim());
  if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) {
    return href;
  }

  // Already absolute with a scheme (http:, https:, etc.).
  if (/^[a-z][a-z0-9+.-]*:/i.test(href)) {
    return href;
  }

  try {
    return new URL(href, `${portalAppUrl}/`).toString();
  } catch {
    return href;
  }
};

const escapeHtml = (value) =>
  String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");

const decodeHtmlEntitiesOnce = (value) =>
  value.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (fullMatch, code) => {
    const normalizedCode = String(code);
    if (normalizedCode.startsWith("#x") || normalizedCode.startsWith("#X")) {
      const parsed = Number.parseInt(normalizedCode.slice(2), 16);
      return Number.isInteger(parsed) && parsed >= 0 && parsed <= 0x10ffff ? String.fromCodePoint(parsed) : fullMatch;
    }

    if (normalizedCode.startsWith("#")) {
      const parsed = Number.parseInt(normalizedCode.slice(1), 10);
      return Number.isInteger(parsed) && parsed >= 0 && parsed <= 0x10ffff ? String.fromCodePoint(parsed) : fullMatch;
    }

    const named = {
      amp: "&",
      apos: "'",
      gt: ">",
      lt: "<",
      nbsp: " ",
      quot: '"',
    };
    return named[normalizedCode.toLowerCase()] ?? fullMatch;
  });

const decodeHtmlEntities = (value) => {
  let decoded = value;
  for (let pass = 0; pass < 3; pass += 1) {
    const next = decodeHtmlEntitiesOnce(decoded);
    if (next === decoded) {
      return decoded;
    }
    decoded = next;
  }
  return decoded;
};

/** Collapse markdown to a single plain-text preview line for the home feed. */
const stripMarkdownForPreview = (value) => {
  if (typeof value !== "string" || !value.trim()) {
    return "";
  }

  return decodeHtmlEntities(value)
    .replace(/<img\b[^>]*\/?>/gi, "[Image]")
    .replace(/<[^>]+>/g, " ")
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/^>\s?/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "")
    .replace(/`{1,3}([^`]+)`{1,3}/g, "$1")
    .replace(/[*_~]+/g, "")
    .replace(/\\([\\`*_[\]{}()#+\-.!~>])/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
};

const formatInlineMarkdown = (value) => {
  let html = escapeHtml(value);
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
  // Absolute and Portal-relative links (e.g. /oi/oiperson_…). Relative paths use appUrl.
  html = html.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_match, text, escapedHref) => {
    const resolved = resolvePortalMarkdownHref(escapedHref);
    if (!resolved) {
      return text;
    }

    return `<a href="${escapeHtml(resolved)}" target="_blank" rel="noopener noreferrer">${text}</a>`;
  });
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/__([^_]+)__/g, "<strong>$1</strong>");
  html = html.replace(/(^|[\s(])\*([^*\n]+)\*(?=[\s).,]|$)/g, "$1<em>$2</em>");
  html = html.replace(/(^|[\s(])_([^_\n]+)_(?=[\s).,]|$)/g, "$1<em>$2</em>");
  return html;
};

/** Lightweight markdown → HTML for meeting summary cards (no external deps). */
const renderMarkdownToHtml = (markdown) => {
  const source = decodeHtmlEntities(markdown).replace(/\r\n?/g, "\n").trim();
  if (!source) {
    return "";
  }

  const lines = source.split("\n");
  const blocks = [];
  let index = 0;

  const flushParagraph = (buffer) => {
    if (buffer.length === 0) {
      return;
    }
    blocks.push(`<p>${formatInlineMarkdown(buffer.join(" "))}</p>`);
    buffer.length = 0;
  };

  while (index < lines.length) {
    const line = lines[index];
    const trimmed = line.trim();

    if (!trimmed) {
      index += 1;
      continue;
    }

    if (trimmed.startsWith("```")) {
      const codeLines = [];
      index += 1;
      while (index < lines.length && !lines[index].trim().startsWith("```")) {
        codeLines.push(lines[index]);
        index += 1;
      }
      if (index < lines.length) {
        index += 1;
      }
      blocks.push(`<pre><code>${escapeHtml(codeLines.join("\n"))}</code></pre>`);
      continue;
    }

    const headingMatch = trimmed.match(/^(#{1,4})\s+(.+)$/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      blocks.push(`<h${level}>${formatInlineMarkdown(headingMatch[2])}</h${level}>`);
      index += 1;
      continue;
    }

    if (/^>\s?/.test(trimmed)) {
      const quoteLines = [];
      while (index < lines.length && /^>\s?/.test(lines[index].trim())) {
        quoteLines.push(lines[index].trim().replace(/^>\s?/, ""));
        index += 1;
      }
      blocks.push(`<blockquote><p>${formatInlineMarkdown(quoteLines.join(" "))}</p></blockquote>`);
      continue;
    }

    if (/^[-*+]\s+/.test(trimmed)) {
      const items = [];
      while (index < lines.length && /^[-*+]\s+/.test(lines[index].trim())) {
        items.push(`<li>${formatInlineMarkdown(lines[index].trim().replace(/^[-*+]\s+/, ""))}</li>`);
        index += 1;
      }
      blocks.push(`<ul>${items.join("")}</ul>`);
      continue;
    }

    if (/^\d+\.\s+/.test(trimmed)) {
      const items = [];
      while (index < lines.length && /^\d+\.\s+/.test(lines[index].trim())) {
        items.push(`<li>${formatInlineMarkdown(lines[index].trim().replace(/^\d+\.\s+/, ""))}</li>`);
        index += 1;
      }
      blocks.push(`<ol>${items.join("")}</ol>`);
      continue;
    }

    const paragraphLines = [trimmed];
    index += 1;
    while (index < lines.length) {
      const next = lines[index].trim();
      if (!next || next.startsWith("```") || /^#{1,4}\s+/.test(next) || /^>\s?/.test(next) || /^[-*+]\s+/.test(next) || /^\d+\.\s+/.test(next)) {
        break;
      }
      paragraphLines.push(next);
      index += 1;
    }
    flushParagraph(paragraphLines);
  }

  return blocks.join("");
};

const appendSummaryContent = (parent, summary, format) => {
  const element = document.createElement(format === "markdown" ? "div" : "p");
  element.className = "klear-insights-card-summary";
  element.dataset.format = format;

  if (format === "markdown") {
    element.innerHTML = renderMarkdownToHtml(summary);
  } else {
    element.textContent = stripMarkdownForPreview(summary);
  }

  parent.appendChild(element);
  return element;
};

const getPrimaryInsightPerson = (job) => {
  const participants = Array.isArray(job?.participants) ? job.participants : [];
  for (const participant of participants) {
    const name = typeof participant?.name === "string" ? participant.name.trim() : "";
    const email = typeof participant?.email === "string" ? participant.email.trim() : "";
    if (!name && !email) {
      continue;
    }

    return {
      name: name || email,
      email,
      label: name || email,
    };
  }

  return null;
};

const getPersonRouteKey = (person) => {
  if (!person) {
    return null;
  }

  if (typeof person.email === "string" && person.email.trim()) {
    return person.email.trim().toLowerCase();
  }

  if (typeof person.label === "string" && person.label.trim()) {
    return person.label.trim();
  }

  return null;
};

const looksLikeEmail = (value) => typeof value === "string" && value.includes("@");

const hasVisibleWikiSectionContent = (content) => typeof content === "string" && content.trim().length > 0;

const getInitials = (label) => {
  const parts = label
    .split(/\s+/)
    .map((part) => part.trim())
    .filter(Boolean);

  if (parts.length === 0) {
    return "?";
  }

  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }

  return `${parts[0][0] ?? ""}${parts[1][0] ?? ""}`.toUpperCase();
};

const formatMeetingSchedule = (date) => {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return "No date";
  }

  const day = new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(date);
  const time = new Intl.DateTimeFormat(undefined, {
    hour: "numeric",
    minute: "2-digit",
  }).format(date);

  return `${day}, ${time}`;
};

const formatMeetingScheduleFull = (date) => {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return "No date";
  }

  return new Intl.DateTimeFormat(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
};

const formatCardTime = (date) => {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return "";
  }

  return new Intl.DateTimeFormat(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(date);
};

const getJobParticipants = (job) => {
  if (!Array.isArray(job?.participants)) {
    return [];
  }

  return job.participants
    .map((participant) => {
      const name = typeof participant?.name === "string" ? participant.name.trim() : "";
      const email = typeof participant?.email === "string" ? participant.email.trim() : "";
      if (!name && !email) {
        return null;
      }

      return {
        name: name || email,
        email,
        label: name || email,
        isOrganizer: Boolean(participant?.organizer || participant?.is_organizer || participant?.isOrganizer),
      };
    })
    .filter(Boolean);
};

const getJobExternalRefs = (job) => (job?.external_refs && typeof job.external_refs === "object" ? job.external_refs : null);

const normalizeMeetCode = (value) => {
  if (typeof value !== "string") {
    return "";
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return "";
  }

  const fromUrl = /meet\.google\.com\/([a-z0-9-]+)/i.exec(trimmed);
  if (fromUrl?.[1]) {
    return fromUrl[1].toLowerCase();
  }

  // Codes look like "abc-defg-hij"; ignore conference-record ids.
  if (/^[a-z0-9]{2,4}-[a-z0-9]{3,5}-[a-z0-9]{3,5}$/i.test(trimmed)) {
    return trimmed.toLowerCase();
  }

  return "";
};

/** Pull a Meet code from free text when external_refs omitted gmeet_code. */
const extractMeetCodeFromText = (value) => {
  if (typeof value !== "string" || !value.trim()) {
    return "";
  }

  const fromUrl = /meet\.google\.com\/([a-z0-9]{2,4}-[a-z0-9]{3,5}-[a-z0-9]{3,5})/i.exec(value);
  if (fromUrl?.[1]) {
    return fromUrl[1].toLowerCase();
  }

  const bare = /\b([a-z0-9]{2,4}-[a-z0-9]{3,5}-[a-z0-9]{3,5})\b/i.exec(value);
  return bare?.[1] ? bare[1].toLowerCase() : "";
};

const getJoiningDetails = (job) => {
  const refs = getJobExternalRefs(job) ?? {};

  const directUrlCandidates = [refs.meet_url, refs.meeting_url, refs.hangout_link, refs.hangoutLink, refs.join_url, refs.joinWebUrl];
  let meetUrl = null;
  for (const candidate of directUrlCandidates) {
    if (typeof candidate === "string" && /^https?:\/\//i.test(candidate.trim())) {
      meetUrl = candidate.trim();
      break;
    }
  }

  const meetCode =
    normalizeMeetCode(refs.gmeet_code) ||
    normalizeMeetCode(refs.meeting_code) ||
    normalizeMeetCode(refs.meet_code) ||
    extractMeetCodeFromText(typeof job?.title === "string" ? job.title : "") ||
    extractMeetCodeFromText(typeof job?.summary === "string" ? job.summary : "");

  if (!meetUrl && meetCode) {
    meetUrl = `https://meet.google.com/${meetCode}`;
  }

  if (!meetUrl && typeof refs.zoom_id === "string" && /^\d{9,}$/.test(refs.zoom_id.trim())) {
    meetUrl = `https://zoom.us/j/${refs.zoom_id.trim()}`;
  }

  const phone =
    (typeof refs.phone === "string" && refs.phone.trim()) ||
    (typeof refs.phone_number === "string" && refs.phone_number.trim()) ||
    (typeof refs.dial_in === "string" && refs.dial_in.trim()) ||
    "";
  const pin =
    (typeof refs.pin === "string" && refs.pin.trim()) ||
    (typeof refs.passcode === "string" && refs.passcode.trim()) ||
    (typeof refs.meeting_pin === "string" && refs.meeting_pin.trim()) ||
    "";

  if (!meetUrl && !phone && !pin) {
    return null;
  }

  return {
    meetUrl,
    meetCode: meetCode || normalizeMeetCode(meetUrl),
    phone,
    pin,
  };
};

const encodeGoogleCalendarEventId = (eventId, calendarId = "primary") => {
  const raw = `${eventId.trim()} ${(calendarId || "primary").trim() || "primary"}`;
  return btoa(raw).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
};

const getCalendarEventUrl = (job) => {
  const refs = getJobExternalRefs(job);
  if (!refs) {
    return null;
  }

  const directUrlCandidates = [refs.html_link, refs.htmlLink, refs.calendar_url, refs.calendarUrl, refs.event_url, refs.eventUrl];
  for (const candidate of directUrlCandidates) {
    if (typeof candidate === "string" && /^https?:\/\//i.test(candidate.trim())) {
      return candidate.trim();
    }
  }

  const source = typeof refs.source === "string" ? refs.source.trim().toLowerCase() : "";
  const microsoftEventId =
    (typeof refs.teams_id === "string" && refs.teams_id.trim()) ||
    (typeof refs.outlook_event_id === "string" && refs.outlook_event_id.trim()) ||
    (typeof refs.calendar_event_id === "string" &&
      (source.includes("microsoft") || source.includes("outlook") || source.includes("teams")) &&
      refs.calendar_event_id.trim()) ||
    "";

  if (microsoftEventId) {
    return `https://outlook.office.com/calendar/item/${encodeURIComponent(microsoftEventId)}`;
  }

  const googleEventId =
    (typeof refs.gevent_id === "string" && refs.gevent_id.trim()) ||
    (typeof refs.calendar_event_id === "string" && refs.calendar_event_id.trim()) ||
    (typeof refs.calendarEventId === "string" && refs.calendarEventId.trim()) ||
    "";

  if (!googleEventId) {
    return null;
  }

  const calendarId =
    (typeof refs.calendar_id === "string" && refs.calendar_id.trim()) || (typeof refs.calendarId === "string" && refs.calendarId.trim()) || "primary";

  return `https://www.google.com/calendar/event?eid=${encodeGoogleCalendarEventId(googleEventId, calendarId)}`;
};

const getDayBucket = (date) => {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return { key: "undated", label: "Earlier" };
  }

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const dayDiff = Math.round((startOfToday.getTime() - startOfDate.getTime()) / 86_400_000);

  if (dayDiff === 0) {
    return { key: "today", label: "Today" };
  }

  if (dayDiff === 1) {
    return { key: "yesterday", label: "Yesterday" };
  }

  return {
    key: startOfDate.toISOString().slice(0, 10),
    label: new Intl.DateTimeFormat(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
    }).format(date),
  };
};

const normalizeJobs = (data) => (Array.isArray(data?.jobs) ? data.jobs : []);

const getJobsWithSummaries = (jobs) => jobs.filter((job) => Boolean(getJobSummary(job)));

const HOME_ICON_SVG = `
  <svg aria-hidden="true" viewBox="0 0 24 24" focusable="false">
    <path
      fill="currentColor"
      d="M12 3.5 4.5 10v9.5h5V14h5v5.5h5V10L12 3.5Z"
    />
  </svg>
`;

const CALENDAR_ICON_SVG = `
  <svg aria-hidden="true" viewBox="0 0 24 24" focusable="false">
    <path
      fill="currentColor"
      d="M7 2.75a.75.75 0 0 1 .75.75V5h8.5V3.5a.75.75 0 0 1 1.5 0V5H19a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h1.25V3.5A.75.75 0 0 1 7 2.75ZM5 9.5v9.5h14V9.5H5Z"
    />
  </svg>
`;

const EXTERNAL_LINK_ICON_SVG = `
  <svg aria-hidden="true" viewBox="0 0 24 24" focusable="false">
    <path
      fill="currentColor"
      d="M14 3h7v7h-2V6.41l-9.29 9.3-1.42-1.42 9.3-9.29H14V3ZM5 5h6v2H7v10h10v-4h2v6H5V5Z"
    />
  </svg>
`;

const createUploadTranscriptButton = () => {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "klear-insights-button";
  button.textContent = "Upload transcript";
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    void sendRuntimeMessage({ type: "open-portal-path", path: "/meetings/new" }).catch((error) => {
      console.error("Failed to open Portal upload page", error);
    });
  });
  return button;
};

const buildStreakCommentMessage = (job) => {
  const summary = getJobSummary(job);
  const title = getJobTitle(job);
  if (!summary) {
    return "";
  }

  const plainSummary = stripMarkdownForPreview(summary) || summary.trim();
  if (!title || title === "Untitled meeting") {
    return plainSummary;
  }

  return `Meeting summary: ${title}\n\n${plainSummary}`;
};

const getJobProcessingId = (job) => {
  if (typeof job?.processing_id === "string" && job.processing_id.trim()) {
    return job.processing_id.trim();
  }
  if (typeof job?.process_id === "string" && job.process_id.trim()) {
    return job.process_id.trim();
  }
  if (typeof job?.id === "string" && job.id.trim()) {
    return job.id.trim();
  }
  return "";
};

const buildStreakTranscriptMessage = (job, transcript) => {
  const trimmedTranscript = typeof transcript === "string" ? transcript.trim() : "";
  if (!trimmedTranscript) {
    return "";
  }

  const title = getJobTitle(job);
  if (!title || title === "Untitled meeting") {
    return `Meeting transcript\n\n${trimmedTranscript}`;
  }

  return `Meeting transcript: ${title}\n\n${trimmedTranscript}`;
};

const getPortalInsightsMountRoot = () => {
  const overlay = document.getElementById(PORTAL_OVERLAY_ID);
  if (!(overlay instanceof HTMLElement)) {
    return null;
  }

  // Insights UI lives in the overlay shadow root. Light-DOM children of the host are not
  // rendered (no <slot>), so modals must mount inside the shadow tree to be visible.
  return overlay.shadowRoot ?? overlay;
};

const openAddSummaryToStreakModal = ({ job, host } = {}) => {
  const summary = getJobSummary(job);
  if (!summary) {
    window.alert("No summary available to add.");
    return;
  }

  const mountHost = host instanceof HTMLElement || host instanceof ShadowRoot ? host : getPortalInsightsMountRoot();
  if (!mountHost) {
    return;
  }

  mountHost.querySelectorAll("[data-klear-streak-modal='true']").forEach((node) => node.remove());

  const backdrop = document.createElement("div");
  backdrop.className = "klear-streak-modal-backdrop";
  backdrop.dataset.portalStreakModal = "true";

  const modal = document.createElement("div");
  modal.className = "klear-streak-modal";
  modal.addEventListener("click", (event) => event.stopPropagation());

  appendText(modal, "h3", "klear-streak-modal-title", "Add summary to Streak");
  appendText(modal, "p", "klear-streak-modal-copy", "Choose which Streak box should receive this meeting summary.");

  const pipelineField = document.createElement("div");
  appendText(pipelineField, "label", "klear-streak-modal-label", "Pipeline");
  const pipelineSelect = document.createElement("select");
  pipelineSelect.className = "klear-streak-modal-select";
  pipelineSelect.disabled = true;
  const loadingOption = document.createElement("option");
  loadingOption.value = "";
  loadingOption.textContent = "Loading pipelines…";
  pipelineSelect.appendChild(loadingOption);
  pipelineField.appendChild(pipelineSelect);
  modal.appendChild(pipelineField);

  const boxesSection = document.createElement("div");
  boxesSection.hidden = true;
  appendText(boxesSection, "label", "klear-streak-modal-label", "Box");
  const boxesList = document.createElement("div");
  boxesList.className = "klear-streak-box-list";
  boxesSection.appendChild(boxesList);
  modal.appendChild(boxesSection);

  const includeTranscriptLabel = document.createElement("label");
  includeTranscriptLabel.className = "klear-streak-modal-checkbox";
  const includeTranscriptCheckbox = document.createElement("input");
  includeTranscriptCheckbox.type = "checkbox";
  includeTranscriptCheckbox.checked = false;
  const processingId = getJobProcessingId(job);
  includeTranscriptCheckbox.disabled = !processingId;
  includeTranscriptLabel.appendChild(includeTranscriptCheckbox);
  const includeTranscriptCopy = document.createElement("span");
  includeTranscriptCopy.textContent = processingId ? "Include transcript" : "Include transcript (unavailable for this meeting)";
  includeTranscriptLabel.appendChild(includeTranscriptCopy);
  modal.appendChild(includeTranscriptLabel);

  const status = appendText(modal, "p", "klear-streak-modal-status", "");
  status.hidden = true;

  const actions = document.createElement("div");
  actions.className = "klear-streak-modal-actions";
  const cancelButton = document.createElement("button");
  cancelButton.type = "button";
  cancelButton.className = "klear-streak-modal-button";
  cancelButton.textContent = "Cancel";
  const submitButton = document.createElement("button");
  submitButton.type = "button";
  submitButton.className = "klear-streak-modal-button primary";
  submitButton.textContent = "Add summary";
  submitButton.disabled = true;
  actions.appendChild(cancelButton);
  actions.appendChild(submitButton);
  modal.appendChild(actions);

  backdrop.appendChild(modal);
  mountHost.appendChild(backdrop);

  let selectedBoxKey = "";
  let selectedBoxName = "";
  let isPosting = false;

  const closeModal = () => {
    backdrop.remove();
  };

  const setStatus = (message, isError = false) => {
    if (!message) {
      status.hidden = true;
      status.textContent = "";
      status.classList.remove("error");
      return;
    }

    status.hidden = false;
    status.textContent = message;
    status.classList.toggle("error", isError);
  };

  const renderBoxes = (boxes) => {
    clearElement(boxesList);
    selectedBoxKey = "";
    selectedBoxName = "";
    submitButton.disabled = true;

    if (!Array.isArray(boxes) || boxes.length === 0) {
      appendText(boxesList, "p", "klear-streak-modal-status", "No boxes in this pipeline.");
      return;
    }

    boxes.forEach((box) => {
      const boxKey = typeof box?.boxKey === "string" ? box.boxKey : typeof box?.key === "string" ? box.key : "";
      const boxName = typeof box?.name === "string" ? box.name : "Untitled box";
      if (!boxKey) {
        return;
      }

      const item = document.createElement("button");
      item.type = "button";
      item.className = "klear-streak-box-item";
      item.dataset.selected = "false";
      appendText(item, "span", "klear-streak-box-name", boxName);
      if (typeof box?.notes === "string" && box.notes.trim()) {
        appendText(item, "span", "klear-streak-box-notes", box.notes.trim());
      }
      item.addEventListener("click", () => {
        selectedBoxKey = boxKey;
        selectedBoxName = boxName;
        submitButton.disabled = isPosting;
        Array.from(boxesList.querySelectorAll(".klear-streak-box-item")).forEach((node) => {
          node.dataset.selected = node === item ? "true" : "false";
        });
      });
      boxesList.appendChild(item);
    });
  };

  const loadBoxes = async (pipelineKey) => {
    if (!pipelineKey) {
      boxesSection.hidden = true;
      return;
    }

    boxesSection.hidden = false;
    clearElement(boxesList);
    appendText(boxesList, "p", "klear-streak-modal-status", "Loading boxes…");
    submitButton.disabled = true;
    setStatus("");

    try {
      const page = await sendRuntimeMessage({ type: "streak-boxes", pipelineKey, page: 0, limit: 50 });
      renderBoxes(page?.boxes ?? []);
    } catch (error) {
      clearElement(boxesList);
      setStatus(error instanceof Error ? error.message : "Failed to load boxes.", true);
    }
  };

  cancelButton.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    closeModal();
  });

  backdrop.addEventListener("click", () => {
    if (!isPosting) {
      closeModal();
    }
  });

  pipelineSelect.addEventListener("change", () => {
    void loadBoxes(pipelineSelect.value);
  });

  submitButton.addEventListener("click", async (event) => {
    event.preventDefault();
    event.stopPropagation();
    if (!selectedBoxKey || isPosting) {
      return;
    }

    isPosting = true;
    submitButton.disabled = true;
    cancelButton.disabled = true;
    pipelineSelect.disabled = true;
    includeTranscriptCheckbox.disabled = true;
    setStatus("Adding summary…");

    try {
      await sendRuntimeMessage({
        type: "streak-comment",
        boxKey: selectedBoxKey,
        message: buildStreakCommentMessage(job),
      });

      if (includeTranscriptCheckbox.checked) {
        setStatus("Adding transcript…");
        const transcriptResult = await sendRuntimeMessage({
          type: "job-transcript",
          processingId,
        });
        const transcriptMessage = buildStreakTranscriptMessage(job, transcriptResult?.transcript);
        if (!transcriptMessage) {
          throw new Error("No transcript available for this meeting.");
        }
        await sendRuntimeMessage({
          type: "streak-comment",
          boxKey: selectedBoxKey,
          message: transcriptMessage,
        });
        setStatus(`Added summary and transcript to ${selectedBoxName || "Streak"}.`);
      } else {
        setStatus(`Added to ${selectedBoxName || "Streak"}.`);
      }
      window.setTimeout(() => closeModal(), 700);
    } catch (error) {
      isPosting = false;
      cancelButton.disabled = false;
      pipelineSelect.disabled = false;
      includeTranscriptCheckbox.disabled = !processingId;
      submitButton.disabled = !selectedBoxKey;
      setStatus(error instanceof Error ? error.message : "Failed to add summary to Streak.", true);
    }
  });

  void (async () => {
    try {
      const result = await sendRuntimeMessage({ type: "streak-pipelines" });
      const pipelines = Array.isArray(result?.pipelines) ? result.pipelines : [];
      clearElement(pipelineSelect);
      const emptyOption = document.createElement("option");
      emptyOption.value = "";
      emptyOption.textContent = pipelines.length > 0 ? "Select a pipeline" : "No pipelines found";
      pipelineSelect.appendChild(emptyOption);

      let firstPipelineKey = "";
      pipelines.forEach((pipeline) => {
        const key = typeof pipeline?.pipelineKey === "string" ? pipeline.pipelineKey : typeof pipeline?.key === "string" ? pipeline.key : "";
        const name = typeof pipeline?.name === "string" ? pipeline.name : "Untitled pipeline";
        if (!key) {
          return;
        }

        if (!firstPipelineKey) {
          firstPipelineKey = key;
        }

        const option = document.createElement("option");
        option.value = key;
        option.textContent = name;
        pipelineSelect.appendChild(option);
      });
      pipelineSelect.disabled = pipelines.length === 0;
      if (pipelines.length === 0) {
        setStatus("Connect Streak in Portal Settings → Integrations first.", true);
        return;
      }

      pipelineSelect.value = firstPipelineKey;
      void loadBoxes(firstPipelineKey);
    } catch (error) {
      pipelineSelect.disabled = true;
      setStatus(error instanceof Error ? error.message : "Failed to load pipelines.", true);
    }
  })();
};

const createAddToStreakButton = (job, className, { streakConnected = false } = {}) => {
  if (!streakConnected || !getJobSummary(job)) {
    return null;
  }

  const button = document.createElement("button");
  button.type = "button";
  button.className = className;
  button.textContent = "Add to Streak";
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    openAddSummaryToStreakModal({ job });
  });
  return button;
};

const buildStreakContactHash = (contactKey) => {
  const trimmedKey = typeof contactKey === "string" ? contactKey.trim() : "";
  if (!trimmedKey) {
    return "";
  }

  return `#streak/contact/${encodeURIComponent(trimmedKey)}`;
};

const createStreakContactButton = (contact) => {
  const contactKey = typeof contact?.key === "string" ? contact.key.trim() : "";
  const hash = buildStreakContactHash(contactKey);
  if (!hash) {
    return null;
  }

  const button = document.createElement("button");
  button.type = "button";
  button.className = "klear-insights-button secondary";
  button.textContent = "Open in Streak";
  // Same-tab hash update only — a new tab/full navigation breaks Streak's contact view.
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    // Drop sticky Portal hash so handleRouteChange does not snap us back
    // to `#klear/insights/...` after we leave for Streak.
    clearStickyPortalHash();
    lastNonPortalHash = hash;
    if (window.location.hash !== hash) {
      window.location.hash = hash;
    } else {
      unmountPortalInsights();
    }
  });
  return button;
};

const openAddContactToStreakModal = ({ email, displayName, host, onCreated } = {}) => {
  const trimmedEmail = typeof email === "string" ? email.trim() : "";
  if (!looksLikeEmail(trimmedEmail)) {
    window.alert("An email is required to add this person to Streak.");
    return;
  }

  const mountHost = host instanceof HTMLElement || host instanceof ShadowRoot ? host : getPortalInsightsMountRoot();
  if (!mountHost) {
    return;
  }

  mountHost.querySelectorAll("[data-klear-streak-modal='true']").forEach((node) => node.remove());

  const backdrop = document.createElement("div");
  backdrop.className = "klear-streak-modal-backdrop";
  backdrop.dataset.portalStreakModal = "true";

  const modal = document.createElement("div");
  modal.className = "klear-streak-modal";
  modal.addEventListener("click", (event) => event.stopPropagation());

  const personLabel = typeof displayName === "string" && displayName.trim() ? displayName.trim() : trimmedEmail;
  appendText(modal, "h3", "klear-streak-modal-title", "Add contact to Streak");
  appendText(modal, "p", "klear-streak-modal-copy", `Choose which Streak team should own ${personLabel}.`);

  const teamField = document.createElement("div");
  appendText(teamField, "label", "klear-streak-modal-label", "Team");
  const teamSelect = document.createElement("select");
  teamSelect.className = "klear-streak-modal-select";
  teamSelect.disabled = true;
  const loadingOption = document.createElement("option");
  loadingOption.value = "";
  loadingOption.textContent = "Loading teams…";
  teamSelect.appendChild(loadingOption);
  teamField.appendChild(teamSelect);
  modal.appendChild(teamField);

  const status = appendText(modal, "p", "klear-streak-modal-status", "");
  status.hidden = true;

  const actions = document.createElement("div");
  actions.className = "klear-streak-modal-actions";
  const cancelButton = document.createElement("button");
  cancelButton.type = "button";
  cancelButton.className = "klear-streak-modal-button";
  cancelButton.textContent = "Cancel";
  const submitButton = document.createElement("button");
  submitButton.type = "button";
  submitButton.className = "klear-streak-modal-button primary";
  submitButton.textContent = "Add contact";
  submitButton.disabled = true;
  actions.appendChild(cancelButton);
  actions.appendChild(submitButton);
  modal.appendChild(actions);

  backdrop.appendChild(modal);
  mountHost.appendChild(backdrop);

  let isPosting = false;

  const closeModal = () => {
    backdrop.remove();
  };

  const setStatus = (message, isError = false) => {
    if (!message) {
      status.hidden = true;
      status.textContent = "";
      status.classList.remove("error");
      return;
    }
    status.hidden = false;
    status.textContent = message;
    status.classList.toggle("error", isError);
  };

  cancelButton.addEventListener("click", () => {
    if (!isPosting) {
      closeModal();
    }
  });
  backdrop.addEventListener("click", () => {
    if (!isPosting) {
      closeModal();
    }
  });

  teamSelect.addEventListener("change", () => {
    submitButton.disabled = !teamSelect.value || isPosting;
  });

  submitButton.addEventListener("click", () => {
    const teamKey = teamSelect.value;
    if (!teamKey || isPosting) {
      return;
    }

    isPosting = true;
    submitButton.disabled = true;
    cancelButton.disabled = true;
    teamSelect.disabled = true;
    setStatus("Adding contact…");

    void sendRuntimeMessage({
      type: "streak-contact-create",
      email: trimmedEmail,
      teamKey,
      name: personLabel,
    })
      .then((created) => {
        const contact = created?.contact ?? created;
        closeModal();
        if (typeof onCreated === "function") {
          onCreated(contact);
        }
      })
      .catch((error) => {
        isPosting = false;
        submitButton.disabled = !teamSelect.value;
        cancelButton.disabled = false;
        teamSelect.disabled = false;
        setStatus(error instanceof Error ? error.message : String(error), true);
      });
  });

  void sendRuntimeMessage({ type: "streak-teams" })
    .then((result) => {
      const teams = Array.isArray(result?.teams) ? result.teams : [];
      clearElement(teamSelect);

      if (teams.length === 0) {
        const emptyOption = document.createElement("option");
        emptyOption.value = "";
        emptyOption.textContent = "No teams found";
        teamSelect.appendChild(emptyOption);
        teamSelect.disabled = true;
        setStatus("No Streak teams were found for this API key.", true);
        return;
      }

      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "Select a team";
      teamSelect.appendChild(placeholder);

      for (const team of teams) {
        const key = typeof team?.key === "string" ? team.key.trim() : "";
        if (!key) {
          continue;
        }
        const option = document.createElement("option");
        option.value = key;
        option.textContent = typeof team?.name === "string" && team.name.trim() ? team.name.trim() : key;
        teamSelect.appendChild(option);
      }

      teamSelect.disabled = false;
      if (teams.length === 1 && typeof teams[0]?.key === "string" && teams[0].key.trim()) {
        teamSelect.value = teams[0].key.trim();
        submitButton.disabled = false;
      }
    })
    .catch((error) => {
      clearElement(teamSelect);
      const emptyOption = document.createElement("option");
      emptyOption.value = "";
      emptyOption.textContent = "Could not load teams";
      teamSelect.appendChild(emptyOption);
      teamSelect.disabled = true;
      setStatus(error instanceof Error ? error.message : String(error), true);
    });
};

const paintPersonStreakAction = (actionsHost, { email, displayName, streakConnected }) => {
  if (!(actionsHost instanceof HTMLElement)) {
    return;
  }

  clearElement(actionsHost);

  if (!streakConnected || !looksLikeEmail(email)) {
    return;
  }

  const loading = appendText(actionsHost, "span", "klear-insights-main-subtitle", "Checking Streak…");

  void sendRuntimeMessage({ type: "streak-contact-lookup", email })
    .then((result) => {
      if (!actionsHost.isConnected) {
        return;
      }

      clearElement(actionsHost);
      const contact = result?.contact ?? null;
      if (contact?.key) {
        const openButton = createStreakContactButton(contact);
        if (openButton) {
          actionsHost.appendChild(openButton);
        }
        return;
      }

      const addButton = document.createElement("button");
      addButton.type = "button";
      addButton.className = "klear-insights-button secondary";
      addButton.textContent = "Add to Streak";
      addButton.addEventListener("click", () => {
        openAddContactToStreakModal({
          email,
          displayName,
          onCreated: (createdContact) => {
            if (!actionsHost.isConnected) {
              return;
            }
            clearElement(actionsHost);
            const openButton = createStreakContactButton(createdContact);
            if (openButton) {
              actionsHost.appendChild(openButton);
              return;
            }
            actionsHost.appendChild(addButton);
          },
        });
      });
      actionsHost.appendChild(addButton);
    })
    .catch((error) => {
      if (!actionsHost.isConnected) {
        return;
      }

      const message = error instanceof Error ? error.message : String(error);
      if (/not connected/i.test(message) || /\b404\b/.test(message)) {
        clearElement(actionsHost);
        return;
      }

      loading.textContent = "Streak lookup failed";
    });
};

let streakConnectionCache = {
  status: "unknown",
  checkedAt: 0,
};

const STREAK_CONNECTION_CACHE_MS = 60_000;

const _resolveStreakConnected = async ({ force = false } = {}) => {
  const now = Date.now();
  if (
    !force &&
    (streakConnectionCache.status === "connected" || streakConnectionCache.status === "missing") &&
    now - streakConnectionCache.checkedAt < STREAK_CONNECTION_CACHE_MS
  ) {
    return streakConnectionCache.status === "connected";
  }

  try {
    // Same signal as Portal: pipelines 200 only when a Streak API key is saved for the workspace.
    const result = await sendRuntimeMessage({ type: "streak-pipelines" });
    const connected = Array.isArray(result?.pipelines);
    streakConnectionCache = {
      status: connected ? "connected" : "missing",
      checkedAt: now,
    };
    return connected;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const code = error?.code;
    if (code === "auth_required") {
      streakConnectionCache = { status: "unknown", checkedAt: now };
      return false;
    }

    if (/not connected/i.test(message) || /api key not found/i.test(message) || /\b404\b/.test(message)) {
      streakConnectionCache = { status: "missing", checkedAt: now };
      return false;
    }

    // Treat other failures as unknown so we don't flash a dead control permanently.
    streakConnectionCache = { status: "unknown", checkedAt: now };
    return false;
  }
};

const CALENDAR_EDIT_CONTROL_ATTR = "data-klear-calendar-edit";

const paintCalendarEditControl = (control, calendarUrl) => {
  if (!(control instanceof HTMLElement)) {
    return;
  }

  const labelHtml = `${EXTERNAL_LINK_ICON_SVG}<span>Edit in Calendar</span>`;

  if (typeof calendarUrl === "string" && /^https?:\/\//i.test(calendarUrl)) {
    if (control instanceof HTMLAnchorElement) {
      control.href = calendarUrl;
      control.removeAttribute("aria-disabled");
      control.classList.remove("is-disabled");
      return;
    }

    const link = document.createElement("a");
    link.className = "klear-insights-edit-calendar";
    link.setAttribute(CALENDAR_EDIT_CONTROL_ATTR, "true");
    link.href = calendarUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.innerHTML = labelHtml;
    control.replaceWith(link);
    return;
  }

  // Keep the control visible even when we do not have an event id yet.
  if (control instanceof HTMLButtonElement) {
    return;
  }

  const stub = document.createElement("button");
  stub.type = "button";
  stub.className = "klear-insights-edit-calendar is-disabled";
  stub.setAttribute(CALENDAR_EDIT_CONTROL_ATTR, "true");
  stub.setAttribute("aria-disabled", "true");
  stub.title = "Calendar event link unavailable for this meeting";
  stub.innerHTML = labelHtml;
  stub.addEventListener("click", (event) => {
    event.preventDefault();
  });
  control.replaceWith(stub);
};

const createCalendarEditControl = (job) => {
  const calendarUrl = getCalendarEventUrl(job);
  const control = document.createElement(calendarUrl ? "a" : "button");
  control.className = "klear-insights-edit-calendar";
  control.setAttribute(CALENDAR_EDIT_CONTROL_ATTR, "true");
  control.innerHTML = `${EXTERNAL_LINK_ICON_SVG}<span>Edit in Calendar</span>`;

  if (calendarUrl && control instanceof HTMLAnchorElement) {
    control.href = calendarUrl;
    control.target = "_blank";
    control.rel = "noopener noreferrer";
    return control;
  }

  if (control instanceof HTMLButtonElement) {
    control.type = "button";
    control.classList.add("is-disabled");
    control.setAttribute("aria-disabled", "true");
    control.title = "Calendar event link unavailable for this meeting";
    control.addEventListener("click", (event) => {
      event.preventDefault();
    });
  }

  return control;
};

const renderFocusLoading = (target) => {
  clearElement(target);

  const container = document.createElement("div");
  container.className = "klear-focus-loading";
  target.appendChild(container);

  const card = document.createElement("section");
  card.className = "klear-focus-loading-card";
  container.appendChild(card);

  const mark = document.createElement("span");
  mark.className = "klear-focus-loading-mark";
  mark.setAttribute("aria-hidden", "true");
  mark.innerHTML = WORK_ICON_SVG;
  card.appendChild(mark);

  appendText(card, "h2", "klear-focus-loading-title", "Getting Focus ready");
  appendText(card, "p", "klear-focus-loading-copy", "Loading your recent conversations…");
  card.appendChild(document.createElement("div")).className = "klear-focus-loading-bar";
};

const renderError = (target, message = "") => {
  clearElement(target);

  const container = document.createElement("div");
  container.className = "klear-focus-error";
  target.appendChild(container);

  const card = document.createElement("section");
  card.className = "klear-focus-error-card";
  container.appendChild(card);

  const mark = appendText(card, "span", "klear-focus-error-mark", "!");
  mark.setAttribute("aria-hidden", "true");
  appendText(card, "h2", "klear-focus-error-title", "Uh oh");
  appendText(
    card,
    "p",
    "klear-focus-error-copy",
    message || "There was an issue loading Focus. Reload Gmail or the extension and try again. If it keeps happening, contact support.",
  );

  const retryButton = appendText(card, "button", "klear-focus-error-retry", "Try again");
  retryButton.type = "button";
  retryButton.addEventListener("click", () => loadInsights(target));

  if (message.includes(GOOGLE_WORKSPACE_ADMIN_SUBJECT_MISSING) || message.includes(GOOGLE_WORKSPACE_GMAIL_SCOPE_MISSING)) {
    const integrationsButton = appendText(card, "button", "klear-focus-error-integrations", "Open Integrations");
    integrationsButton.type = "button";
    integrationsButton.addEventListener("click", () => {
      integrationsButton.disabled = true;
      void sendRuntimeMessage({ type: "open-portal-path", path: "/settings/integrations/workspace" }).catch((error) => {
        integrationsButton.disabled = false;
        console.error("Failed to open Portal integrations", error);
      });
    });
  }
};

const renderWorkspaceRequired = async (target, message) => {
  clearElement(target);

  const container = document.createElement("div");
  container.className = "klear-focus-error";
  target.appendChild(container);

  const card = document.createElement("section");
  card.className = "klear-focus-error-card";
  container.appendChild(card);

  const mark = appendText(card, "span", "klear-focus-error-mark", "!");
  mark.setAttribute("aria-hidden", "true");
  appendText(card, "h2", "klear-focus-error-title", "Choose a workspace");
  appendText(card, "p", "klear-focus-error-copy", message || "Choose the workspace Klear should connect to.");

  let stored = null;
  try {
    stored = await readExtensionStorage(["user", SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]);
  } catch (error) {
    console.error("[Klear Focus] Failed to read available workspaces", error);
  }

  const workspaces = getStoredWorkspaces(stored);
  if (workspaces.length === 0) {
    appendText(card, "p", "klear-focus-error-copy", "Sign in again to load the workspaces available to you.");
    const retryButton = appendText(card, "button", "klear-focus-error-retry", "Try again");
    retryButton.type = "button";
    retryButton.addEventListener("click", () => loadInsights(target));
    return;
  }

  const workspaceField = document.createElement("label");
  workspaceField.className = "klear-focus-workspace-field";
  workspaceField.htmlFor = "klear-focus-workspace-select";
  workspaceField.textContent = "Workspace";
  card.appendChild(workspaceField);

  const workspaceSelect = document.createElement("select");
  workspaceSelect.id = "klear-focus-workspace-select";
  workspaceSelect.className = "klear-focus-workspace-select";
  workspaceField.appendChild(workspaceSelect);

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "Choose a workspace";
  placeholder.disabled = true;
  placeholder.selected = true;
  workspaceSelect.appendChild(placeholder);

  for (const workspace of workspaces) {
    const option = document.createElement("option");
    option.value = workspace.ownerUserId;
    option.textContent = typeof workspace.name === "string" && workspace.name ? workspace.name : "Untitled workspace";
    workspaceSelect.appendChild(option);
  }

  workspaceSelect.addEventListener("change", () => {
    const ownerUserId = workspaceSelect.value;
    if (!ownerUserId) {
      return;
    }

    workspaceSelect.disabled = true;
    void chrome.storage.local
      .set({ [SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]: ownerUserId })
      .then(() => loadInsights(target))
      .catch((error) => {
        workspaceSelect.disabled = false;
        console.error("[Klear Focus] Failed to save the selected workspace", error);
      });
  });
};

const getFriendlyAuthMessage = (message) => {
  if (/401|403|unauthorized|forbidden|expired/i.test(message)) {
    return "Klear needs you to sign in to Portal before it can load your conversations.";
  }

  return message || "Sign in to Portal to connect Klear.";
};

const renderAuthRequired = (target, message) => {
  clearElement(target);

  const container = document.createElement("div");
  container.className = "klear-insights-auth-required";
  target.appendChild(container);

  const card = document.createElement("section");
  card.className = "klear-insights-auth-card";
  container.appendChild(card);
  const mark = document.createElement("span");
  mark.className = "klear-insights-auth-mark";
  mark.setAttribute("aria-hidden", "true");
  mark.innerHTML = WORK_ICON_SVG;
  card.appendChild(mark);

  appendText(card, "h3", "klear-insights-auth-title", "Sign in to Portal");
  const copy = appendText(card, "p", "klear-insights-auth-copy", getFriendlyAuthMessage(message));

  const loginButton = document.createElement("button");
  loginButton.type = "button";
  loginButton.className = "klear-insights-button";
  loginButton.textContent = "Sign in";
  card.appendChild(loginButton);

  loginButton.addEventListener("click", () => {
    loginButton.disabled = true;
    loginButton.textContent = "Signing in...";
    copy.textContent = "Complete sign-in in the opened Portal window. You will return here when it finishes.";

    void sendRuntimeMessage({ type: "extension-login" })
      .then(() => loadInsights(target))
      .catch((error) => {
        const errorMessage = error instanceof Error ? error.message : String(error);
        renderAuthRequired(target, getFriendlyAuthMessage(errorMessage));
      });
  });
};

const renderMeetingList = (list, jobs, onSelectMeeting) => {
  clearElement(list);

  if (jobs.length === 0) {
    appendText(list, "div", "klear-insights-empty", "No meetings yet.");
    return;
  }

  for (const job of jobs) {
    const jobId = typeof job?.id === "string" ? job.id : "";
    const item = document.createElement("button");
    item.type = "button";
    item.className = "klear-insights-meeting-item";
    item.dataset.meetingId = jobId;
    if (selectedMeetingId && selectedMeetingId === jobId) {
      item.dataset.active = "true";
    }

    const icon = document.createElement("span");
    icon.className = "klear-insights-meeting-icon";
    icon.innerHTML = CALENDAR_ICON_SVG;
    item.appendChild(icon);

    const copy = document.createElement("div");
    copy.className = "klear-insights-meeting-copy";
    appendText(copy, "p", "klear-insights-meeting-title", getJobTitle(job));
    appendText(copy, "p", "klear-insights-meeting-meta", formatMeetingSchedule(getJobDateValue(job)));
    item.appendChild(copy);

    item.addEventListener("click", () => {
      onSelectMeeting(jobId || null);
    });

    list.appendChild(item);
  }
};

const createInsightCard = (
  job,
  { showMeetingLink = true, showActions = true, statusLabel = null, summaryFormat = "plain", streakConnected = false } = {},
) => {
  const date = getJobDateValue(job);
  const card = document.createElement("article");
  card.className = "klear-insights-card";

  const header = document.createElement("div");
  header.className = "klear-insights-card-header";

  const identity = document.createElement("div");
  identity.className = "klear-insights-card-identity";

  const person = getPrimaryInsightPerson(job);
  const participantLabel = person?.label ?? "Meeting insight";
  const personKey = getPersonRouteKey(person);
  const personPill = document.createElement(personKey ? "button" : "div");
  if (personKey) {
    personPill.type = "button";
  }
  personPill.className = "klear-insights-person-pill";
  appendText(personPill, "div", "klear-insights-avatar", getInitials(participantLabel));
  appendText(personPill, "p", "klear-insights-card-name", participantLabel);
  if (personKey) {
    personPill.setAttribute("aria-label", `Open ${participantLabel}`);
    personPill.title = `Open ${participantLabel}`;
    personPill.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      navigatePortalRoute({ personKey });
    });
  }
  identity.appendChild(personPill);

  const meta = document.createElement("div");
  meta.className = "klear-insights-card-meta";
  const timeLabel = formatCardTime(date);
  if (timeLabel) {
    appendText(meta, "span", "klear-insights-card-time", timeLabel);
  }
  if (showMeetingLink) {
    const jobId = typeof job?.id === "string" ? job.id : "";
    if (jobId) {
      const meetingLink = document.createElement("button");
      meetingLink.type = "button";
      meetingLink.className = "klear-insights-card-meeting";
      meetingLink.textContent = getJobTitle(job);
      meetingLink.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        navigatePortalRoute(jobId);
      });
      meta.appendChild(meetingLink);
    } else {
      appendText(meta, "span", "klear-insights-card-time", getJobTitle(job));
    }
  }
  if (meta.childNodes.length > 0) {
    identity.appendChild(meta);
  }
  header.appendChild(identity);

  if (statusLabel) {
    appendText(header, "span", "klear-insights-card-status", statusLabel);
  } else if (showActions) {
    const addButton = createAddToStreakButton(job, "klear-insights-card-action", { streakConnected });
    if (addButton) {
      const actions = document.createElement("div");
      actions.className = "klear-insights-card-actions";
      actions.appendChild(addButton);
      header.appendChild(actions);
    }
  }

  card.appendChild(header);

  const body = document.createElement("div");
  body.className = "klear-insights-card-body";
  appendSummaryContent(body, getJobSummary(job), summaryFormat);
  card.appendChild(body);

  return card;
};

const renderGuestInsightCards = (
  target,
  jobs,
  { groupByDay = true, emptyMessage = "No meeting summaries yet.", summaryFormat = "plain", streakConnected = false, showActions = true } = {},
) => {
  clearElement(target);

  const jobsWithSummaries = getJobsWithSummaries(jobs);
  if (jobsWithSummaries.length === 0) {
    appendText(target, "div", "klear-insights-empty", emptyMessage);
    return;
  }

  if (!groupByDay) {
    const cards = document.createElement("div");
    cards.className = "klear-insights-card-list";
    for (const job of jobsWithSummaries) {
      cards.appendChild(
        createInsightCard(job, {
          showMeetingLink: false,
          showActions,
          summaryFormat,
          streakConnected,
        }),
      );
    }
    target.appendChild(cards);
    return;
  }

  const groups = new Map();
  for (const job of jobsWithSummaries) {
    const date = getJobDateValue(job);
    const bucket = getDayBucket(date);
    const existing = groups.get(bucket.key);
    if (existing) {
      existing.jobs.push(job);
      continue;
    }

    groups.set(bucket.key, {
      label: bucket.label,
      jobs: [job],
    });
  }

  for (const group of groups.values()) {
    const section = document.createElement("section");
    section.className = "klear-insights-day-group";
    appendText(section, "h3", "klear-insights-day-label", group.label);

    const cards = document.createElement("div");
    cards.className = "klear-insights-card-list";
    for (const job of group.jobs) {
      cards.appendChild(createInsightCard(job, { summaryFormat, streakConnected, showActions }));
    }

    section.appendChild(cards);
    target.appendChild(section);
  }
};

const paintJoiningDetails = (list, details) => {
  clearElement(list);

  if (!details?.meetUrl && !details?.phone && !details?.pin) {
    appendText(list, "p", "klear-insights-meta-copy", "Joining details will show here when available.");
    return;
  }

  if (details.meetUrl) {
    const link = document.createElement("a");
    link.className = "klear-insights-join-link";
    link.href = details.meetUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = details.meetCode ? `meet.google.com/${details.meetCode}` : details.meetUrl;
    list.appendChild(link);
  }

  if (details.phone) {
    appendText(list, "div", "klear-insights-meta-copy", details.phone);
  }

  if (details.pin) {
    appendText(list, "div", "klear-insights-meta-copy", `PIN: ${details.pin}`);
  }
};

const getJoiningLookupIds = (job) => {
  const refs = getJobExternalRefs(job) ?? {};
  const fromText =
    extractMeetCodeFromText(typeof job?.title === "string" ? job.title : "") ||
    extractMeetCodeFromText(typeof job?.summary === "string" ? job.summary : "");

  return {
    gmeetId: typeof refs.gmeet_id === "string" ? refs.gmeet_id.trim() : "",
    geventId: typeof refs.gevent_id === "string" ? refs.gevent_id.trim() : "",
    gmeetCode: normalizeMeetCode(refs.gmeet_code) || normalizeMeetCode(refs.meeting_code) || normalizeMeetCode(refs.meet_code) || fromText,
  };
};

const renderJoiningInfo = (column, job, { onRemoteJoiningInfo } = {}) => {
  appendText(column, "h3", "klear-insights-meta-title", "Joining info");

  const list = document.createElement("div");
  list.className = "klear-insights-join-list";
  column.appendChild(list);

  const localDetails = getJoiningDetails(job);
  const lookup = getJoiningLookupIds(job);
  const hasLookup = Boolean(lookup.gmeetId || lookup.geventId || lookup.gmeetCode);

  if (localDetails?.meetUrl || localDetails?.phone || localDetails?.pin) {
    paintJoiningDetails(list, localDetails);
  } else if (hasLookup) {
    appendText(list, "p", "klear-insights-meta-copy", "Loading joining details...");
  } else {
    paintJoiningDetails(list, null);
    return;
  }

  if (!hasLookup) {
    return;
  }

  // Resolve meet code / calendar dial-in from Portal when the job only has gmeet_id/gevent_id.
  void sendRuntimeMessage({
    type: "fetch-joining-info",
    gmeetId: lookup.gmeetId,
    geventId: lookup.geventId,
    gmeetCode: lookup.gmeetCode || localDetails?.meetCode || "",
  })
    .then((remote) => {
      const merged = {
        meetUrl: localDetails?.meetUrl || (typeof remote?.meetUrl === "string" ? remote.meetUrl : null),
        meetCode: localDetails?.meetCode || (typeof remote?.meetCode === "string" ? remote.meetCode : null),
        phone: localDetails?.phone || (typeof remote?.phone === "string" ? remote.phone : null),
        pin: localDetails?.pin || (typeof remote?.pin === "string" ? remote.pin : null),
      };
      paintJoiningDetails(list, merged);
      if (typeof onRemoteJoiningInfo === "function") {
        onRemoteJoiningInfo(remote);
      }
    })
    .catch((error) => {
      console.warn("[Klear Gmail POC] Joining info fetch failed:", error);
      if (!localDetails?.meetUrl && !localDetails?.phone && !localDetails?.pin) {
        paintJoiningDetails(list, localDetails);
      }
    });
};

const GUEST_LIST_COLLAPSED_COUNT = 3;

const createGuestRow = (participant) => {
  const row = document.createElement("div");
  row.className = "klear-insights-guest-row";
  appendText(row, "div", "klear-insights-avatar sm", getInitials(participant.label));

  const copy = document.createElement("div");
  copy.className = "klear-insights-guest-copy";
  const displayName = participant.isOrganizer ? `${participant.name} (Organizer)` : participant.name;
  appendText(copy, "p", "klear-insights-guest-name", displayName);
  if (participant.email && participant.email !== participant.name) {
    appendText(copy, "p", "klear-insights-guest-email", participant.email);
  }
  row.appendChild(copy);
  return row;
};

const renderGuests = (column, job) => {
  const participants = getJobParticipants(job);
  const guestLabel = participants.length === 1 ? "1 Guest" : `${participants.length} Guests`;
  appendText(column, "h3", "klear-insights-meta-title", guestLabel);

  if (participants.length === 0) {
    appendText(column, "p", "klear-insights-meta-copy", "Guests will show here when available.");
    return;
  }

  appendText(column, "p", "klear-insights-guest-count", `${participants.length} on the invite`);

  const list = document.createElement("div");
  list.className = "klear-insights-guest-list";
  const canCollapse = participants.length > GUEST_LIST_COLLAPSED_COUNT;
  let isExpanded = false;

  const renderGuestRows = () => {
    clearElement(list);
    const visibleParticipants = isExpanded ? participants : participants.slice(0, GUEST_LIST_COLLAPSED_COUNT);

    for (const participant of visibleParticipants) {
      list.appendChild(createGuestRow(participant));
    }

    if (!canCollapse) {
      return;
    }

    const remaining = participants.length - GUEST_LIST_COLLAPSED_COUNT;
    const expandButton = document.createElement("button");
    expandButton.type = "button";
    expandButton.className = "klear-insights-guest-expand";
    expandButton.textContent = isExpanded ? "Show less" : `Show ${remaining} more`;
    expandButton.addEventListener("click", () => {
      isExpanded = !isExpanded;
      renderGuestRows();
    });
    list.appendChild(expandButton);
  };

  renderGuestRows();
  column.appendChild(list);
};

const renderWikiSections = (target, sections, { displayName = "this person", wikiPageId = null } = {}) => {
  clearElement(target);

  const visibleSections = (Array.isArray(sections) ? sections : []).filter((section) => hasVisibleWikiSectionContent(section?.content));

  if (visibleSections.length === 0) {
    appendText(target, "div", "klear-insights-empty", "No wiki sections yet for this person.");
  } else {
    const list = document.createElement("div");
    list.className = "klear-insights-wiki-sections";

    for (const section of visibleSections) {
      const sectionEl = document.createElement("section");
      sectionEl.className = "klear-insights-wiki-section";
      appendText(sectionEl, "h3", "klear-insights-wiki-section-title", section.title || section.key || "Section");

      const body = document.createElement("div");
      body.className = "klear-insights-wiki-section-body klear-insights-card-summary";
      body.dataset.format = "markdown";
      body.innerHTML = renderMarkdownToHtml(section.content);
      sectionEl.appendChild(body);
      list.appendChild(sectionEl);
    }

    target.appendChild(list);
  }

  const trimmedPageId = typeof wikiPageId === "string" ? wikiPageId.trim() : "";
  if (!trimmedPageId) {
    return;
  }

  const learnMore = document.createElement("a");
  learnMore.className = "klear-insights-wiki-learn-more";
  learnMore.href = resolvePortalMarkdownHref(`/wiki/${encodeURIComponent(trimmedPageId)}`);
  learnMore.target = "_blank";
  learnMore.rel = "noopener noreferrer";
  learnMore.textContent = `Learn more about ${displayName} in Internode`;
  learnMore.style.marginTop = "40px";
  learnMore.style.textDecoration = "none";
  target.appendChild(learnMore);
};

const pickPersonWikiPage = (wikiPages) => {
  const pages = (Array.isArray(wikiPages) ? wikiPages : []).filter((page) => typeof page?.id === "string" && page.id.trim());
  if (pages.length === 0) {
    return null;
  }

  return pages.find((page) => String(page?.doc_type ?? "").toLowerCase() === "person") ?? pages[0];
};

const loadPersonWikiPayload = async (personKey) => {
  const trimmedKey = typeof personKey === "string" ? personKey.trim() : "";
  if (!trimmedKey) {
    throw new Error("Person key is required.");
  }

  if (looksLikeEmail(trimmedKey)) {
    const details = await sendRuntimeMessage({ type: "person-details", email: trimmedKey });
    const page = pickPersonWikiPage(details?.wiki_pages);
    if (!page) {
      return {
        details,
        page: null,
        sections: [],
      };
    }

    const wiki = await sendRuntimeMessage({ type: "wiki-page", pageId: page.id });
    return {
      details,
      page,
      sections: Array.isArray(wiki?.sections) ? wiki.sections : [],
    };
  }

  const list = await sendRuntimeMessage({
    type: "wiki-pages",
    query: trimmedKey,
    type: "person",
    limit: 5,
  });
  const page = pickPersonWikiPage(list?.pages);
  if (!page) {
    return {
      details: { name: trimmedKey, email: "" },
      page: null,
      sections: [],
    };
  }

  const wiki = await sendRuntimeMessage({ type: "wiki-page", pageId: page.id });
  return {
    details: {
      name: typeof wiki?.name === "string" && wiki.name.trim() ? wiki.name.trim() : trimmedKey,
      email: "",
    },
    page,
    sections: Array.isArray(wiki?.sections) ? wiki.sections : [],
  };
};

const renderPersonDetailView = (main, personKey, { streakConnected = false } = {}) => {
  clearElement(main);
  main.dataset.view = "person";

  const fallbackLabel = looksLikeEmail(personKey) ? personKey : personKey || "Person";

  const mainHeader = document.createElement("div");
  mainHeader.className = "klear-insights-main-header";

  const heading = document.createElement("div");
  heading.className = "klear-insights-main-heading";

  const titleRow = document.createElement("div");
  titleRow.className = "klear-insights-card-identity";
  const avatar = appendText(titleRow, "div", "klear-insights-avatar", getInitials(fallbackLabel));
  const title = document.createElement("h2");
  title.className = "klear-insights-main-title";
  title.textContent = fallbackLabel;
  titleRow.appendChild(title);
  heading.appendChild(titleRow);

  const subtitle = appendText(heading, "p", "klear-insights-main-subtitle", "Loading wiki…");
  mainHeader.appendChild(heading);

  const mainActions = document.createElement("div");
  mainActions.className = "klear-insights-main-actions";
  mainHeader.appendChild(mainActions);
  main.appendChild(mainHeader);

  appendText(main, "h3", "klear-insights-subsection-title", "");
  const wikiBody = document.createElement("div");
  main.appendChild(wikiBody);
  appendText(wikiBody, "div", "klear-insights-empty", "Loading wiki sections…");

  void loadPersonWikiPayload(personKey)
    .then((payload) => {
      if (selectedPersonKey !== personKey) {
        return;
      }

      const displayName =
        (typeof payload.details?.name === "string" && payload.details.name.trim()) ||
        (typeof payload.page?.name === "string" && payload.page.name.trim()) ||
        fallbackLabel;
      const email = (typeof payload.details?.email === "string" && payload.details.email.trim()) || (looksLikeEmail(personKey) ? personKey : "");

      title.textContent = displayName;
      avatar.textContent = getInitials(displayName);
      subtitle.textContent = email && email.toLowerCase() !== displayName.toLowerCase() ? email : "Person details";

      const wikiPageId = (typeof payload.page?.id === "string" && payload.page.id.trim()) || null;
      renderWikiSections(wikiBody, payload.sections, { displayName, wikiPageId });
      paintPersonStreakAction(mainActions, { email, displayName, streakConnected });
    })
    .catch((error) => {
      if (selectedPersonKey !== personKey) {
        return;
      }

      const message = error instanceof Error ? error.message : String(error);
      subtitle.textContent = "Could not load person details";
      clearElement(wikiBody);
      appendText(wikiBody, "div", "klear-insights-empty", message || "Failed to load wiki sections.");
    });
};

const renderHomeView = (main, jobs, { streakConnected = false } = {}) => {
  clearElement(main);
  main.dataset.view = "home";

  const mainHeader = document.createElement("div");
  mainHeader.className = "klear-insights-main-header";

  const heading = document.createElement("div");
  heading.className = "klear-insights-main-heading";
  appendText(heading, "h2", "klear-insights-main-title", "Guest insights");
  mainHeader.appendChild(heading);

  const mainActions = document.createElement("div");
  mainActions.className = "klear-insights-main-actions";

  const autoAdd = document.createElement("label");
  autoAdd.className = "klear-insights-auto-add";
  const autoAddSwitch = document.createElement("button");
  autoAddSwitch.type = "button";
  autoAddSwitch.className = "klear-insights-switch";
  autoAddSwitch.setAttribute("role", "switch");
  autoAddSwitch.setAttribute("aria-checked", "false");
  autoAddSwitch.setAttribute("aria-label", "Auto add");
  autoAddSwitch.addEventListener("click", (event) => {
    event.preventDefault();
  });
  autoAdd.appendChild(autoAddSwitch);
  appendText(autoAdd, "span", "", "Auto add");
  mainActions.appendChild(autoAdd);
  mainHeader.appendChild(mainActions);
  main.appendChild(mainHeader);

  const mainBody = document.createElement("div");
  main.appendChild(mainBody);
  // Match Portal meetings list: Add to Streak lives on meeting detail header, not home cards.
  renderGuestInsightCards(mainBody, jobs, { summaryFormat: "plain", streakConnected, showActions: false });
};

const renderMeetingDetailView = (main, job, { streakConnected = false } = {}) => {
  clearElement(main);
  main.dataset.view = "detail";

  const date = getJobDateValue(job);

  const mainHeader = document.createElement("div");
  mainHeader.className = "klear-insights-main-header";

  const heading = document.createElement("div");
  heading.className = "klear-insights-main-heading";
  appendText(heading, "h2", "klear-insights-main-title", getJobTitle(job));
  appendText(heading, "p", "klear-insights-main-subtitle", formatMeetingScheduleFull(date));
  heading.appendChild(createCalendarEditControl(job));
  mainHeader.appendChild(heading);

  const mainActions = document.createElement("div");
  mainActions.className = "klear-insights-main-actions";
  const addToStreakButton = createAddToStreakButton(job, "klear-insights-button secondary", { streakConnected });
  if (addToStreakButton) {
    mainActions.appendChild(addToStreakButton);
  }
  mainHeader.appendChild(mainActions);
  main.appendChild(mainHeader);

  const metaGrid = document.createElement("div");
  metaGrid.className = "klear-insights-meta-grid";
  const joiningColumn = document.createElement("div");
  const guestsColumn = document.createElement("div");
  renderJoiningInfo(joiningColumn, job, {
    onRemoteJoiningInfo: (remote) => {
      const calendarUrl =
        (typeof remote?.calendarUrl === "string" && remote.calendarUrl.trim()) ||
        (typeof remote?.geventId === "string" && remote.geventId.trim()
          ? `https://www.google.com/calendar/event?eid=${encodeGoogleCalendarEventId(remote.geventId.trim())}`
          : "");
      if (!calendarUrl) {
        return;
      }

      const control = heading.querySelector(`[${CALENDAR_EDIT_CONTROL_ATTR}="true"]`);
      paintCalendarEditControl(control, calendarUrl);
    },
  });
  renderGuests(guestsColumn, job);
  metaGrid.appendChild(joiningColumn);
  metaGrid.appendChild(guestsColumn);
  main.appendChild(metaGrid);

  appendText(main, "h3", "klear-insights-subsection-title", "Guest insights");
  const insightsBody = document.createElement("div");
  main.appendChild(insightsBody);
  renderGuestInsightCards(insightsBody, [job], {
    groupByDay: false,
    emptyMessage: "No summary available for this meeting yet.",
    summaryFormat: "markdown",
    // Header owns the Streak action for the meeting detail.
    showActions: false,
    streakConnected,
  });
};

const _renderInsights = (shell, data, { streakConnected = false } = {}) => {
  clearElement(shell);

  const jobs = normalizeJobs(data);
  const summaryCount = getJobsWithSummaries(jobs).length;

  const sidebar = document.createElement("aside");
  sidebar.className = "klear-insights-sidebar";
  shell.appendChild(sidebar);

  const sidebarHeader = document.createElement("div");
  sidebarHeader.className = "klear-insights-sidebar-header";
  appendText(sidebarHeader, "h2", "klear-insights-sidebar-title", "Insights");
  sidebarHeader.appendChild(createUploadTranscriptButton());
  sidebar.appendChild(sidebarHeader);

  const nav = document.createElement("div");
  nav.className = "klear-insights-nav";
  sidebar.appendChild(nav);

  const homeButton = document.createElement("button");
  homeButton.type = "button";
  homeButton.className = "klear-insights-nav-item";

  const homeIcon = document.createElement("span");
  homeIcon.className = "klear-insights-nav-icon";
  homeIcon.innerHTML = HOME_ICON_SVG;
  homeButton.appendChild(homeIcon);
  appendText(homeButton, "span", "klear-insights-nav-label", "Home");
  if (summaryCount > 0) {
    appendText(homeButton, "span", "klear-insights-badge", String(summaryCount));
  }
  nav.appendChild(homeButton);

  appendText(sidebar, "div", "klear-insights-section-label", "My meetings");
  const meetingList = document.createElement("div");
  meetingList.className = "klear-insights-meeting-list";
  sidebar.appendChild(meetingList);

  const main = document.createElement("section");
  main.className = "klear-insights-main";
  shell.appendChild(main);

  const refreshView = () => {
    homeButton.dataset.active = selectedMeetingId || selectedPersonKey ? "false" : "true";
    renderMeetingList(meetingList, jobs, (meetingId) => {
      navigatePortalRoute(meetingId);
    });

    if (selectedPersonKey) {
      renderPersonDetailView(main, selectedPersonKey, { streakConnected });
      return;
    }

    if (!selectedMeetingId) {
      renderHomeView(main, jobs, { streakConnected });
      return;
    }

    const selectedJob = jobs.find((job) => job?.id === selectedMeetingId) ?? null;
    if (!selectedJob) {
      navigatePortalRoute(null, { replace: true });
      return;
    }

    renderMeetingDetailView(main, selectedJob, { streakConnected });
  };

  homeButton.addEventListener("click", () => {
    navigatePortalRoute(null);
  });

  refreshInsightsView = refreshView;
  refreshView();
};

const isGmailSelectedPillBackground = (backgroundColor) => {
  if (!backgroundColor) {
    return false;
  }

  const normalized = backgroundColor.replace(/\s+/g, "").toLowerCase();
  return normalized === "rgb(211,227,253)" || normalized.startsWith("rgba(211,227,253,") || normalized === "#d3e3fd";
};

const restoreGmailRailSelection = () => {
  for (const node of clearedRailSelectionNodes) {
    if (!(node instanceof HTMLElement)) {
      continue;
    }

    node.style.removeProperty("background-color");
    node.style.removeProperty("background");
    delete node.dataset.portalClearedSelectedBg;
  }
  clearedRailSelectionNodes = [];
};

/**
 * Gmail keeps its selected navigation item in its own UI state. While Klear is open we
 * visually clear those blue pills so Klear is the only active item.
 */
const clearGmailRailSelection = (rail, { reset = true } = {}) => {
  if (reset) {
    restoreGmailRailSelection();
  }

  if (!(rail instanceof HTMLElement)) {
    return;
  }

  for (const child of rail.children) {
    if (!(child instanceof HTMLElement) || child.id === PORTAL_BUTTON_ID) {
      continue;
    }

    child.setAttribute("aria-selected", "false");
    child.setAttribute("aria-current", "false");

    const candidates = [child, ...child.querySelectorAll("*")];
    for (const node of candidates) {
      if (
        !(node instanceof HTMLElement) ||
        node.dataset.portalClearedSelectedBg === "true" ||
        node.closest(`#${PORTAL_BUTTON_ID}`)
      ) {
        continue;
      }

      const style = window.getComputedStyle(node);
      if (!isGmailSelectedPillBackground(style.backgroundColor)) {
        continue;
      }

      node.dataset.portalClearedSelectedBg = "true";
      node.style.setProperty("background-color", "transparent", "important");
      node.style.setProperty("background", "transparent", "important");
      clearedRailSelectionNodes.push(node);
    }
  }
};

const setPortalRailActive = (isActive) => {
  const button = document.getElementById(PORTAL_BUTTON_ID);
  const navigation = getGmailNavigation();

  if (button) {
    if (isActive) {
      button.dataset.active = "true";
      button.setAttribute("aria-pressed", "true");
      button.setAttribute("aria-current", "page");
      // Drop the keyboard focus ring so Insights doesn't look double-selected.
      if (document.activeElement === button) {
        button.blur();
      }
    } else {
      button.removeAttribute("data-active");
      button.setAttribute("aria-pressed", "false");
      button.removeAttribute("aria-current");
    }
  }

  if (!navigation) {
    return;
  }

  if (isActive) {
    navigation.dataset.klearInsightsActive = "true";
    clearGmailRailSelection(navigation, { reset: true });
  } else {
    delete navigation.dataset.klearInsightsActive;
    restoreGmailRailSelection();
  }
};

/** Re-assert Insights selection without tearing down prior clears (avoids observer loops). */
const maintainPortalRailActive = () => {
  if (!document.getElementById(PORTAL_OVERLAY_ID)) {
    setPortalRailActive(false);
    return;
  }

  const button = document.getElementById(PORTAL_BUTTON_ID);
  const navigation = getGmailNavigation();

  if (button) {
    button.dataset.active = "true";
    button.setAttribute("aria-pressed", "true");
    button.setAttribute("aria-current", "page");
  }

  if (navigation) {
    navigation.dataset.klearInsightsActive = "true";
    clearGmailRailSelection(navigation, { reset: false });
  }
};

const unmountPortalInsights = () => {
  document.getElementById(PORTAL_OVERLAY_ID)?.remove();
  selectedMeetingId = null;
  selectedPersonKey = null;
  selectedFocusConversationId = null;
  selectedFocusContactName = null;
  refreshInsightsView = null;
  setPortalRailActive(false);
};

window.addEventListener(
  "klear-open-gmail-thread",
  (event) => {
    const threadId = event instanceof CustomEvent ? event.detail?.threadId : null;
    if (typeof threadId !== "string" || !threadId) {
      return;
    }

    // Focus uses a sticky route to survive Gmail reloads. Clear it before navigating or the
    // route watcher restores Focus over the Gmail thread that the user asked to open.
    clearStickyPortalHash();
    unmountPortalInsights();
    window.location.hash = `#all/${encodeURIComponent(threadId)}`;
  },
  { signal: controller.signal },
);

const createOverlay = () => {
  if (!document.body) {
    throw new Error("Could not find Gmail document body");
  }

  document.getElementById(PORTAL_OVERLAY_ID)?.remove();

  const overlay = document.createElement("div");
  overlay.id = PORTAL_OVERLAY_ID;
  overlay.className = "klear-gmail-main-overlay";
  updateOverlayBounds(overlay);

  const shadowRoot = overlay.attachShadow({ mode: "open" });
  const styles = document.createElement("style");
  styles.textContent = PORTAL_OVERLAY_STYLES;
  shadowRoot.appendChild(styles);

  const shell = document.createElement("div");
  shell.className = "klear-insights-shell";
  shadowRoot.appendChild(shell);

  document.body.appendChild(overlay);
  return shell;
};

const loadInsights = async (shell) => {
  // Cached routes transition instantly. A route whose analysis has not been loaded yet
  // gets the normal loading state while its data is fetched.
  if (!hasCachedFocusRoute()) {
    renderFocusLoading(shell);
  }

  try {
    if (!document.getElementById(PORTAL_OVERLAY_ID) || !parsePortalRoute()) {
      return;
    }

    if (!window.KlearFocusConversations) {
      throw new Error("Focus conversations UI failed to load.");
    }

    const focusData = await sendFocusMessage({ type: "fetch-focus-conversations" });
    let analysis = null;
    let analysisError = null;
    let contactAnalysis = null;
    let contactAnalysisError = null;

    if (selectedFocusConversationId && !selectedFocusContactName) {
      try {
        const result = await sendFocusMessage({
          type: "fetch-focus-analysis",
          threadId: selectedFocusConversationId,
        });
        analysis = result?.analysis ?? null;
      } catch (error) {
        analysisError = error instanceof Error ? error.message : "Thread analysis could not be loaded.";
      }
    }

    if (selectedFocusConversationId && selectedFocusContactName) {
      const conversations = Array.isArray(focusData?.conversations) ? focusData.conversations : [];
      const selectedConversation = conversations.find((conversation) => conversation?.id === selectedFocusConversationId);
      const participants = Array.isArray(selectedConversation?.participants) ? selectedConversation.participants : [];
      const selectedName = selectedFocusContactName.trim().toLowerCase();
      const selectedParticipant = participants.find((participant) => {
        const name = typeof participant?.name === "string" ? participant.name.trim().toLowerCase() : "";
        const email = typeof participant?.email === "string" ? participant.email.trim().toLowerCase() : "";
        return name === selectedName || email === selectedName;
      });
      const contactEmail = typeof selectedParticipant?.email === "string" ? selectedParticipant.email.trim() : "";

      if (!contactEmail) {
        contactAnalysisError = "This contact does not have an email address available from the thread.";
      } else {
        try {
          const contactRouteKey = getFocusContactRouteCacheKey(selectedFocusConversationId, selectedFocusContactName);
          const contactRequest = sendFocusMessage({ type: "fetch-focus-contact-analysis", email: contactEmail });
          focusTabCache.contactRouteAnalyses.set(contactRouteKey, contactRequest);
          void contactRequest.catch(() => {
            if (focusTabCache.contactRouteAnalyses.get(contactRouteKey) === contactRequest) {
              focusTabCache.contactRouteAnalyses.delete(contactRouteKey);
            }
          });
          const result = await contactRequest;
          contactAnalysis = result?.analysis ?? null;
        } catch (error) {
          contactAnalysisError = error instanceof Error ? error.message : "Contact analysis could not be loaded.";
        }
      }
    }

    if (!document.getElementById(PORTAL_OVERLAY_ID) || !parsePortalRoute()) {
      return;
    }

    window.KlearFocusConversations.render(shell, focusData, {
      route: {
        conversationId: selectedFocusConversationId,
        contactName: selectedFocusContactName,
      },
      analysis,
      analysisError,
      contactAnalysis,
      contactAnalysisError,
      onNavigate: ({ conversationId = null, contactName = null } = {}) => {
        navigatePortalRoute({
          focusConversationId: conversationId,
          focusContactName: contactName,
        });
      },
    });
    refreshInsightsView = () => void loadInsights(shell);
  } catch (error) {
    if (!document.getElementById(PORTAL_OVERLAY_ID) || !parsePortalRoute()) {
      return;
    }

    const message = error instanceof Error ? error.message : String(error);
    if (error?.code === "auth_required") {
      renderAuthRequired(shell, message);
      return;
    }
    if (error?.code === "workspace_required") {
      await renderWorkspaceRequired(shell, message);
      return;
    }

    console.error("[Klear Focus] Failed to load", error);
    renderError(shell, message);
  }
};

const mountPortalInsights = () => {
  if (document.getElementById(PORTAL_OVERLAY_ID)) {
    return;
  }

  try {
    const shell = createOverlay();
    setPortalRailActive(true);
    void loadInsights(shell);
  } catch (error) {
    setPortalRailActive(false);
    console.error("[Klear Gmail POC]", error);
  }
};

const syncInsightsFromLocation = () => {
  let route = parsePortalRoute();

  // Sticky means the Insights session is still open (refresh recovery or Gmail wiped the hash).
  // Cleared only by leavePortalRoute — never by a transient `#inbox` rewrite.
  if (!route) {
    const stickyHash = readStickyPortalHash();
    if (stickyHash) {
      route = parsePortalHashString(stickyHash);
      if (route && window.location.hash !== stickyHash) {
        history.replaceState(null, "", `${window.location.pathname}${window.location.search}${stickyHash}`);
        lastLocation = window.location.href;
      }
    }
  }

  if (!route) {
    unmountPortalInsights();
    return;
  }

  selectedMeetingId = route.meetingId;
  selectedPersonKey = route.personKey;
  selectedFocusConversationId = route.focusConversationId ?? route.focusContactConversationId;
  selectedFocusContactName = route.focusContactName;

  if (!document.getElementById(PORTAL_OVERLAY_ID)) {
    mountPortalInsights();
    return;
  }

  setPortalRailActive(true);
  refreshInsightsView?.();
};

const openPortalInsights = () => {
  const overlay = document.getElementById(PORTAL_OVERLAY_ID);
  if (parsePortalRoute()) {
    if (!overlay) {
      syncInsightsFromLocation();
      return;
    }

    leavePortalRoute();
    return;
  }

  if (overlay) {
    leavePortalRoute();
    return;
  }

  lastNonPortalHash = window.location.hash || "#inbox";
  navigatePortalRoute(null);
};

const createRailButton = (placement) => {
  const item = document.createElement("div");
  item.id = PORTAL_BUTTON_ID;
  item.className = "klear-gmail-rail-item";
  item.dataset.klearGmailPlacement = placement;
  item.dataset.klearGmailButtonVersion = PORTAL_BUTTON_VERSION;
  item.setAttribute("aria-label", "Open Klear");
  item.setAttribute("aria-pressed", "false");
  item.setAttribute("role", "button");
  item.setAttribute("tabindex", "0");
  item.title = "Open Klear";

  const link = document.createElement("div");
  link.className = "klear-gmail-rail-link";
  link.setAttribute("aria-hidden", "true");
  item.appendChild(link);

  const iconWrap = document.createElement("span");
  iconWrap.className = "klear-gmail-rail-icon-wrap";
  link.appendChild(iconWrap);

  const icon = document.createElement("span");
  icon.className = "klear-gmail-rail-icon";
  icon.innerHTML = WORK_ICON_SVG;
  iconWrap.appendChild(icon);

  const label = document.createElement("span");
  label.className = "klear-gmail-rail-label";
  label.setAttribute("role", "heading");
  label.setAttribute("aria-level", "2");
  label.textContent = "Klear";
  item.appendChild(label);

  item.addEventListener("click", openPortalInsights);
  item.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openPortalInsights();
    }
  });

  return item;
};

const isCurrentRailButton = (button) =>
  button instanceof HTMLElement &&
  button.dataset.klearGmailButtonVersion === PORTAL_BUTTON_VERSION &&
  button.className === "klear-gmail-rail-item" &&
  Boolean(button.querySelector(".klear-gmail-rail-link"));

const getRailButtonPlacement = () => {
  const rail = getGmailAppRail();
  const meetItem = rail ? getMeetRailItem(rail) : null;

  if (meetItem) {
    return { anchor: meetItem, placement: "app-rail", position: "afterend" };
  }

  const inboxItem = getGmailInboxItem();
  if (inboxItem) {
    return { anchor: inboxItem, placement: "sidebar", position: "beforebegin" };
  }

  return null;
};

const placeRailButton = (button, target) => {
  button.dataset.klearGmailPlacement = target.placement;
  target.anchor.insertAdjacentElement(target.position, button);
};

const ensureRailButton = () => {
  const existingButton = document.getElementById(PORTAL_BUTTON_ID);
  const target = getRailButtonPlacement();

  if (!target) {
    return;
  }

  if (existingButton) {
    if (!isCurrentRailButton(existingButton)) {
      const replacementButton = createRailButton(target.placement);
      existingButton.remove();
      placeRailButton(replacementButton, target);
      maintainPortalRailActive();
      return;
    }

    const isInTargetPosition =
      target.position === "afterend" ? existingButton.previousElementSibling === target.anchor : existingButton.nextElementSibling === target.anchor;

    if (existingButton.dataset.klearGmailPlacement !== target.placement || !isInTargetPosition) {
      placeRailButton(existingButton, target);
    }

    // Gmail often re-paints Mail as selected; keep Insights-only selection while open.
    maintainPortalRailActive();
    return;
  }

  placeRailButton(createRailButton(target.placement), target);
  maintainPortalRailActive();
};

const scheduleEnsureRailButton = () => {
  if (railEnsureTimer !== null) {
    return;
  }

  railEnsureTimer = window.setTimeout(() => {
    railEnsureTimer = null;
    ensureRailButton();
    updateOverlayBounds();
  }, 250);
};

const hasGmailShell = () => {
  return Boolean(document.body && getRailButtonPlacement());
};

const waitForGmailShell = async () => {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    if (hasGmailShell()) {
      return true;
    }

    await wait(250);
  }

  return hasGmailShell();
};

const handleNavigationClick = (event) => {
  const target = event.target instanceof Element ? event.target : null;
  if (!target || target.closest(`#${PORTAL_BUTTON_ID}`)) {
    return;
  }

  // Any Gmail left-rail / nav click leaves Insights and clears refresh restore.
  if (!target.closest('div[role="navigation"]')) {
    return;
  }

  if (parsePortalRoute() || readStickyPortalHash() || document.getElementById(PORTAL_OVERLAY_ID)) {
    leavePortalRoute();
  }
};

const handleRouteChange = (event = null) => {
  if (window.location.href === lastLocation) {
    return;
  }

  lastLocation = window.location.href;

  if (parsePortalRoute()) {
    rememberPortalHash(window.location.hash);
    syncInsightsFromLocation();
    scheduleEnsureRailButton();
    return;
  }

  // A browser Back/Forward action is intentional. Do not turn its Inbox route
  // back into Focus just because a sticky hash exists for refresh recovery.
  if (event?.type === "popstate") {
    clearStickyPortalHash();
    const hash = window.location.hash;
    if (hash) {
      lastNonPortalHash = hash;
    }
    syncInsightsFromLocation();
    scheduleEnsureRailButton();
    return;
  }

  const stickyHash = readStickyPortalHash();
  if (stickyHash) {
    // Insights session still active (refresh boot or Gmail wiped the hash).
    // Do NOT clear sticky here — that is leavePortalRoute's job only.
    if (window.location.hash !== stickyHash) {
      history.replaceState(null, "", `${window.location.pathname}${window.location.search}${stickyHash}`);
      lastLocation = window.location.href;
    }
    syncInsightsFromLocation();
    scheduleEnsureRailButton();
    return;
  }

  const hash = window.location.hash;
  if (hash) {
    lastNonPortalHash = hash;
  }

  syncInsightsFromLocation();
  scheduleEnsureRailButton();
};

const startRouteWatcher = () => {
  if (routeCheckTimer !== null) {
    return;
  }

  window.addEventListener("hashchange", handleRouteChange, { signal: controller.signal });
  window.addEventListener("popstate", handleRouteChange, { signal: controller.signal });
  routeCheckTimer = window.setInterval(handleRouteChange, 500);
};

const startObserver = () => {
  if (observer || !document.body) {
    return;
  }

  observer = new MutationObserver(scheduleEnsureRailButton);
  observer.observe(document.body, { childList: true, subtree: true });
};

const boot = async () => {
  sendRuntimeMessageSafely({ type: "dev-reload-connect" }, () => {
    try {
      void chrome.runtime.lastError;
    } catch {
      // The extension was reloaded before the response callback ran.
    }
  });

  // Persist sticky hash before unload so MAIN-world boot can enforce it on the next load.
  window.addEventListener("pagehide", markPortalHashForNextLoad, { signal: controller.signal });
  window.addEventListener("beforeunload", markPortalHashForNextLoad, { signal: controller.signal });

  // Lock restore BEFORE the route watcher runs. Gmail often lands on `#inbox` first; if we
  // treat that as "user left" we clear sticky and lose refresh restore.
  let seedHash = parsePortalRoute() ? window.location.hash : readStickyPortalHash();
  if (seedHash) {
    rememberPortalHash(seedHash);
  } else {
    seedHash = await fetchBackgroundPortalHash();
    if (seedHash) {
      rememberPortalHash(seedHash);
    }
  }

  const restorePromise = restorePortalHashAfterGmailBoot(seedHash);

  if (!parsePortalRoute() && !readStickyPortalHash()) {
    lastNonPortalHash = window.location.hash || "#inbox";
  }

  // pointerdown fires before Gmail navigates, so sticky clears before the hash fight.
  document.addEventListener("pointerdown", handleNavigationClick, {
    capture: true,
    signal: controller.signal,
  });
  document.addEventListener("click", handleNavigationClick, {
    capture: true,
    signal: controller.signal,
  });
  window.addEventListener("resize", () => updateOverlayBounds(), { signal: controller.signal });
  startRouteWatcher();

  const [shellReady] = await Promise.all([waitForGmailShell(), restorePromise]);
  if (!shellReady || controller.signal.aborted) {
    return;
  }

  ensureRailButton();
  startObserver();
  syncInsightsFromLocation();
};

void boot().catch((error) => {
  if (!controller.signal.aborted) {
    console.error("[Klear Gmail POC]", error);
  }
});
