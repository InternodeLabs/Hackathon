const DEFAULT_APP_URL = "https://app.internode.ai";
const APP_URL_STORAGE_KEY = "appUrl:app.internode.ai";
const SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY = "selectedWorkspaceOwnerUserId";
const DEV_RELOAD_REQUESTED_AT_KEY = "klearDevReloadRequestedAt";
const DEV_RELOAD_HEALTH_URL = "";
const DEV_RELOAD_WS_URL = "";
const GMAIL_URL_PATTERN = "https://mail.google.com/*";
const IS_LOCAL_PROOF_EXTENSION = false;
const PORTAL_INSIGHTS_HASH_RE =
  /^#klear\/insights(?:\/(?:meeting\/[^/?#]+|person\/[^/?#]+|conversation\/[^/?#]+|contact\/[^/?#]+\/[^/?#]+))?\/?$/;

/** Last `#portal/...` hash per Gmail tab — survives Gmail wiping the hash before content scripts run. */
const portalHashByTabId = new Map();
const portalHashStorageKey = (tabId) => `klearGmailHash:${tabId}`;

const extractPortalHashFromUrl = (url) => {
  if (typeof url !== "string" || !url.includes("mail.google.com")) {
    return null;
  }

  const hashIndex = url.indexOf("#");
  if (hashIndex < 0) {
    return null;
  }

  const hash = url.slice(hashIndex);
  return PORTAL_INSIGHTS_HASH_RE.test(hash) ? hash : null;
};

const persistPortalHash = (tabId, hash) => {
  portalHashByTabId.set(tabId, hash);
  void chrome.storage.session.set({ [portalHashStorageKey(tabId)]: hash });
};

const forgetPortalHash = (tabId) => {
  portalHashByTabId.delete(tabId);
  void chrome.storage.session.remove(portalHashStorageKey(tabId));
};

const readPersistedPortalHash = async (tabId) => {
  const cached = portalHashByTabId.get(tabId);
  if (typeof cached === "string" && PORTAL_INSIGHTS_HASH_RE.test(cached)) {
    return cached;
  }

  const stored = await chrome.storage.session.get(portalHashStorageKey(tabId));
  const hash = stored[portalHashStorageKey(tabId)];
  if (typeof hash === "string" && PORTAL_INSIGHTS_HASH_RE.test(hash)) {
    portalHashByTabId.set(tabId, hash);
    return hash;
  }

  return null;
};

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = typeof changeInfo.url === "string" ? changeInfo.url : tab.url;
  const portalHash = extractPortalHashFromUrl(url);
  if (portalHash) {
    persistPortalHash(tabId, portalHash);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  forgetPortalHash(tabId);
});


const AUTH_STORAGE_KEYS = ["apiToken", "expiresAt"];
const AUTH_REFRESH_SKEW_MS = 60_000;
const AUTH_REFRESH_ALARM_NAME = "klearRefreshPortalSession";
const AUTH_REFRESH_MIN_DELAY_MINUTES = 1;
const SILENT_AUTH_TIMEOUT_MS = 8_000;

const createCodeVerifier = () => {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return base64UrlEncode(bytes);
};

const createS256CodeChallenge = async (verifier) => {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  return base64UrlEncode(new Uint8Array(digest));
};

const base64UrlEncode = (bytes) => {
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
};

const getAppUrl = async () => {
  const stored = await chrome.storage.local.get([APP_URL_STORAGE_KEY]);
  const storedAppUrl = stored[APP_URL_STORAGE_KEY];
  return typeof storedAppUrl === "string" && storedAppUrl ? storedAppUrl : DEFAULT_APP_URL;
};

const getStoredWorkspaces = (stored) => {
  const workspaces = stored?.user?.workspaces;
  if (!Array.isArray(workspaces)) {
    return [];
  }

  return workspaces.filter((workspace) => typeof workspace?.ownerUserId === "string" && workspace.ownerUserId);
};

const getStoredOwnerUserId = (stored) => {
  const workspaces = getStoredWorkspaces(stored);
  const selectedOwnerUserId = stored?.[SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY];
  if (
    typeof selectedOwnerUserId === "string" &&
    workspaces.some((workspace) => workspace.ownerUserId === selectedOwnerUserId)
  ) {
    return selectedOwnerUserId;
  }

  if (workspaces.length === 1) {
    return workspaces[0].ownerUserId;
  }

  // Extensions connected to an older Portal deployment do not receive workspace
  // data yet. Keep the legacy fallback only for that short compatibility window.
  if (stored?.user && !Array.isArray(stored.user.workspaces)) {
    const ownerUserId = stored.user.ownerUserId;
    return typeof ownerUserId === "string" && ownerUserId ? ownerUserId : stored.user.id ?? "";
  }

  return "";
};

const getRequiredStoredOwnerUserId = (stored) => {
  const ownerUserId = getStoredOwnerUserId(stored);
  if (!ownerUserId) {
    throw new WorkspaceRequiredError("Choose a workspace from the Klear extension menu before continuing.");
  }

  return ownerUserId;
};

class AuthRequiredError extends Error {
  constructor(message) {
    super(message);
    this.name = "AuthRequiredError";
    this.code = "auth_required";
  }
}

class WorkspaceRequiredError extends Error {
  constructor(message) {
    super(message);
    this.name = "WorkspaceRequiredError";
    this.code = "workspace_required";
  }
}

const getErrorResponse = (error) => ({
  ok: false,
  code: error instanceof AuthRequiredError || error instanceof WorkspaceRequiredError ? error.code : "request_failed",
  error: error instanceof Error ? error.message : String(error),
});

const getExpiresAtMs = (expiresAt) => {
  if (typeof expiresAt === "number") {
    return expiresAt < 10_000_000_000 ? expiresAt * 1000 : expiresAt;
  }

  if (typeof expiresAt === "string" && expiresAt) {
    const numericExpiresAt = Number(expiresAt);
    if (Number.isFinite(numericExpiresAt)) {
      return numericExpiresAt < 10_000_000_000 ? numericExpiresAt * 1000 : numericExpiresAt;
    }

    return new Date(expiresAt).getTime();
  }

  return NaN;
};

const isExpired = (expiresAt) => {
  const expiresAtMs = getExpiresAtMs(expiresAt);
  return Number.isFinite(expiresAtMs) && expiresAtMs <= Date.now() + AUTH_REFRESH_SKEW_MS;
};

const withTimeout = (promise, timeoutMs, message) =>
  new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => reject(new Error(message)), timeoutMs);
    promise.then(
      (value) => {
        clearTimeout(timeoutId);
        resolve(value);
      },
      (error) => {
        clearTimeout(timeoutId);
        reject(error);
      },
    );
  });

const clearStoredAuth = async () => {
  await chrome.storage.local.remove(AUTH_STORAGE_KEYS);
  await chrome.alarms.clear(AUTH_REFRESH_ALARM_NAME);
};

const scheduleStoredAuthRefresh = async (expiresAt) => {
  const expiresAtMs = getExpiresAtMs(expiresAt);
  if (!Number.isFinite(expiresAtMs)) {
    await chrome.alarms.clear(AUTH_REFRESH_ALARM_NAME);
    return;
  }

  const delayInMinutes = Math.max(
    AUTH_REFRESH_MIN_DELAY_MINUTES,
    (expiresAtMs - Date.now() - AUTH_REFRESH_SKEW_MS) / 60_000,
  );
  await chrome.alarms.create(AUTH_REFRESH_ALARM_NAME, { delayInMinutes });
};

const restoreStoredAuthRefresh = async () => {
  const stored = await chrome.storage.local.get(["expiresAt", "user"]);
  if (!stored.user?.id) {
    await chrome.alarms.clear(AUTH_REFRESH_ALARM_NAME);
    return;
  }

  if (isExpired(stored.expiresAt)) {
    await refreshStoredAuthSilently();
    return;
  }

  await scheduleStoredAuthRefresh(stored.expiresAt);
};

const readErrorText = async (response) => {
  try {
    const text = await response.clone().text();
    const payload = JSON.parse(text);
    if (typeof payload?.error === "string" && payload.error) {
      return payload.error;
    }
    return text || response.statusText || "Request failed";
  } catch {
    try {
      return await response.text();
    } catch {
      return response.statusText || "Request failed";
    }
  }
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "dev-reload-connect") {
    connectDevReloadSocket();
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "remember-portal-hash") {
    const tabId = sender.tab?.id;
    const hash = typeof message.hash === "string" ? message.hash : "";
    if (typeof tabId === "number" && PORTAL_INSIGHTS_HASH_RE.test(hash)) {
      persistPortalHash(tabId, hash);
    }
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "clear-portal-hash") {
    const tabId = sender.tab?.id;
    if (typeof tabId === "number") {
      forgetPortalHash(tabId);
    }
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "get-portal-hash") {
    const tabId = sender.tab?.id;
    if (typeof tabId !== "number") {
      sendResponse({ ok: true, hash: null });
      return false;
    }

    void readPersistedPortalHash(tabId).then((hash) => {
      sendResponse({ ok: true, hash });
    });
    return true;
  }

  if (message?.type === "extension-login") {
    void handleLogin()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "fetch-jobs") {
    void handleFetchJobs()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "fetch-focus-conversations") {
    void handleFetchFocusConversations()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "fetch-focus-analysis") {
    void handleFetchFocusAnalysis(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "fetch-focus-contact-analysis") {
    void handleFetchFocusContactAnalysis(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "fetch-joining-info") {
    void handleFetchJoiningInfo(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "streak-pipelines") {
    void handleStreakPipelines()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "streak-boxes") {
    void handleStreakBoxes(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "streak-comment") {
    void handleStreakComment(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "streak-contact-lookup") {
    void handleStreakContactLookup(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "streak-teams") {
    void handleStreakTeams()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "streak-contact-create") {
    void handleStreakContactCreate(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "job-transcript") {
    void handleJobTranscript(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "open-portal-path") {
    void handleOpenPortalPath(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "person-details") {
    void handlePersonDetails(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "wiki-pages") {
    void handleWikiPages(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  if (message?.type === "wiki-page") {
    void handleWikiPage(message)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse(getErrorResponse(error)));
    return true;
  }

  return false;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === AUTH_REFRESH_ALARM_NAME) {
    void refreshStoredAuthSilently();
  }
});

chrome.runtime.onStartup.addListener(() => {
  void restoreStoredAuthRefresh();
});

chrome.runtime.onInstalled.addListener((details) => {
  void restoreStoredAuthRefresh();

  if (!IS_LOCAL_PROOF_EXTENSION) {
    return;
  }

  connectDevReloadSocket();

  if (details.reason === "update") {
    void reloadGmailTabsAfterDevReload();
  }
});

async function handleLogin() {
  return createExtensionSession({ interactive: true });
}

async function createExtensionSession({ interactive }) {
  const appUrl = await getAppUrl();
  const redirectUri = chrome.identity.getRedirectURL("callback");
  const state = crypto.randomUUID();
  const codeVerifier = createCodeVerifier();
  const codeChallenge = await createS256CodeChallenge(codeVerifier);

  const authUrl = new URL(`${appUrl}/api/auth/extension/start`);
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("state", state);
  authUrl.searchParams.set("code_challenge", codeChallenge);
  authUrl.searchParams.set("code_challenge_method", "S256");

  const finalUrl = await chrome.identity.launchWebAuthFlow({
    url: authUrl.toString(),
    interactive,
  });

  if (!finalUrl) {
    throw new AuthRequiredError("Sign in to Portal to continue.");
  }

  const callback = new URL(finalUrl);
  const returnedState = callback.searchParams.get("state");
  const code = callback.searchParams.get("code");
  const error = callback.searchParams.get("error");

  if (error) {
    throw new Error(`Auth error: ${error}`);
  }
  if (!code) {
    throw new Error("Auth callback missing code");
  }
  if (returnedState !== state) {
    throw new Error("Auth callback state mismatch");
  }

  const exchangeResponse = await fetch(`${appUrl}/api/auth/extension/exchange`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      code,
      codeVerifier,
      redirectUri,
    }),
  });

  if (!exchangeResponse.ok) {
    const text = await readErrorText(exchangeResponse);
    if (exchangeResponse.status === 401 || exchangeResponse.status === 403) {
      throw new AuthRequiredError("Portal sign-in expired before it finished. Sign in again to continue.");
    }

    throw new Error(`Exchange failed (${exchangeResponse.status}): ${text}`);
  }

  const payload = await exchangeResponse.json();
  if (!payload?.apiToken || !payload?.user?.id) {
    throw new Error("Exchange response missing token or user.");
  }

  const existingStorage = await chrome.storage.local.get([SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]);
  const workspaces = getStoredWorkspaces({ user: payload.user });
  const existingOwnerUserId = existingStorage[SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY];
  const selectedOwnerUserId =
    typeof existingOwnerUserId === "string" && workspaces.some((workspace) => workspace.ownerUserId === existingOwnerUserId)
      ? existingOwnerUserId
      : workspaces.length === 1
        ? workspaces[0].ownerUserId
        : null;

  await chrome.storage.local.set({
    apiToken: payload.apiToken,
    expiresAt: payload.expiresAt,
    user: payload.user,
    redirectUri,
    ...(selectedOwnerUserId ? { [SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]: selectedOwnerUserId } : {}),
  });
  if (!selectedOwnerUserId) {
    await chrome.storage.local.remove(SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY);
  }
  await scheduleStoredAuthRefresh(payload.expiresAt);

  return {
    expiresAt: payload.expiresAt,
    user: payload.user,
    selectedOwnerUserId,
    redirectUri,
    extensionId: chrome.runtime.id,
  };
}

async function refreshStoredAuthSilently() {
  try {
    const refreshed = await withTimeout(
      createExtensionSession({ interactive: false }),
      SILENT_AUTH_TIMEOUT_MS,
      "Portal session refresh timed out.",
    );
    await scheduleStoredAuthRefresh(refreshed.expiresAt);
    return refreshed;
  } catch {
    await clearStoredAuth();
    return null;
  }
}

async function getStoredAuth() {
  return chrome.storage.local.get(["apiToken", "expiresAt", "user", SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]);
}

async function handleFetchJobs({ allowSilentRefresh = true } = {}) {
  const appUrl = await getAppUrl();
  let stored = await getStoredAuth();

  if ((!stored.apiToken || isExpired(stored.expiresAt)) && allowSilentRefresh && stored.user?.id) {
    const refreshed = await refreshStoredAuthSilently();
    if (refreshed) {
      stored = await getStoredAuth();
    }
  }

  if (!stored.apiToken || !stored.user?.id) {
    throw new AuthRequiredError("Sign in to Portal to load jobs.");
  }

  if (isExpired(stored.expiresAt)) {
    await clearStoredAuth();
    throw new AuthRequiredError("Your Portal session expired. Sign in again to continue.");
  }

  // Match /meetings: meeting jobs only (exclude drive/artifact ingest jobs).
  const jobsUrl = new URL(`${appUrl}/api/users/${stored.user.id}/jobs`);
  jobsUrl.searchParams.set("limit", "20");
  jobsUrl.searchParams.set("content_source", "none,meeting_note");

  const response = await fetch(jobsUrl.toString(), {
    headers: {
      Authorization: `Bearer ${stored.apiToken}`,
    },
  });

  if (!response.ok) {
    const text = await response.text();
    if (response.status === 401 || response.status === 403) {
      await clearStoredAuth();
      if (allowSilentRefresh && stored.user?.id) {
        const refreshed = await refreshStoredAuthSilently();
        if (refreshed) {
          return handleFetchJobs({ allowSilentRefresh: false });
        }
      }

      throw new AuthRequiredError("Your Portal session expired. Sign in again to continue.");
    }

    throw new Error(`Jobs request failed (${response.status}): ${text}`);
  }

  return response.json();
}

async function handleFetchJoiningInfo({ gmeetId = "", geventId = "", gmeetCode = "", allowSilentRefresh = true } = {}) {
  const appUrl = await getAppUrl();
  let stored = await getStoredAuth();

  if ((!stored.apiToken || isExpired(stored.expiresAt)) && allowSilentRefresh && stored.user?.id) {
    const refreshed = await refreshStoredAuthSilently();
    if (refreshed) {
      stored = await getStoredAuth();
    }
  }

  if (!stored.apiToken || !stored.user?.id) {
    throw new AuthRequiredError("Sign in to Portal to load joining info.");
  }

  if (isExpired(stored.expiresAt)) {
    await clearStoredAuth();
    throw new AuthRequiredError("Your Portal session expired. Sign in again to continue.");
  }

  const joiningUrl = new URL(`${appUrl}/api/users/${stored.user.id}/meetings/joining-info`);
  if (typeof gmeetId === "string" && gmeetId.trim()) {
    joiningUrl.searchParams.set("gmeet_id", gmeetId.trim());
  }
  if (typeof geventId === "string" && geventId.trim()) {
    joiningUrl.searchParams.set("gevent_id", geventId.trim());
  }
  if (typeof gmeetCode === "string" && gmeetCode.trim()) {
    joiningUrl.searchParams.set("gmeet_code", gmeetCode.trim());
  }

  const response = await fetch(joiningUrl.toString(), {
    headers: {
      Authorization: `Bearer ${stored.apiToken}`,
    },
  });

  if (!response.ok) {
    const text = await response.text();
    if (response.status === 401 || response.status === 403) {
      await clearStoredAuth();
      if (allowSilentRefresh && stored.user?.id) {
        const refreshed = await refreshStoredAuthSilently();
        if (refreshed) {
          return handleFetchJoiningInfo({ gmeetId, geventId, gmeetCode, allowSilentRefresh: false });
        }
      }

      throw new AuthRequiredError("Your Portal session expired. Sign in again to continue.");
    }

    throw new Error(`Joining info request failed (${response.status}): ${text}`);
  }

  return response.json();
}

async function getAuthorizedPortalRequestContext({ allowSilentRefresh = true } = {}) {
  const appUrl = await getAppUrl();
  let stored = await getStoredAuth();

  if ((!stored.apiToken || isExpired(stored.expiresAt)) && allowSilentRefresh && stored.user?.id) {
    const refreshed = await refreshStoredAuthSilently();
    if (refreshed) {
      stored = await getStoredAuth();
    }
  }

  if (!stored.apiToken || !stored.user?.id) {
    throw new AuthRequiredError("Sign in to Portal to continue.");
  }

  if (isExpired(stored.expiresAt)) {
    await clearStoredAuth();
    throw new AuthRequiredError("Your Portal session expired. Sign in again to continue.");
  }

  return { appUrl, stored, allowSilentRefresh };
}

async function fetchAuthorizedPortalJson(path, { method = "GET", body = null, allowNotFound = false, allowSilentRefresh = true } = {}) {
  const { appUrl, stored } = await getAuthorizedPortalRequestContext({ allowSilentRefresh });
  const response = await fetch(`${appUrl}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${stored.apiToken}`,
      ...(body ? { "Content-Type": "application/json" } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (response.status === 404 && allowNotFound) {
    return null;
  }

  if (!response.ok) {
    const text = await response.text();
    if (response.status === 401 || response.status === 403) {
      await clearStoredAuth();
      if (allowSilentRefresh && stored.user?.id) {
        const refreshed = await refreshStoredAuthSilently();
        if (refreshed) {
          return fetchAuthorizedPortalJson(path, { method, body, allowNotFound, allowSilentRefresh: false });
        }
      }

      throw new AuthRequiredError("Your Portal session expired. Sign in again to continue.");
    }

    let message = `Request failed (${response.status}): ${text}`;
    try {
      const payload = JSON.parse(text);
      if (typeof payload?.error === "string" && payload.error.trim()) {
        message = payload.error.trim();
      }
    } catch {
      // Keep fallback message.
    }
    throw new Error(message);
  }

  if (response.status === 204) {
    return null;
  }

  return response.json();
}

async function handleFetchFocusConversations() {
  const { stored } = await getAuthorizedPortalRequestContext();
  const params = new URLSearchParams({
    owner_user_id: getRequiredStoredOwnerUserId(stored),
    limit: "20",
  });
  return fetchAuthorizedPortalJson(`/api/google-workspace-admin/gmail-conversations?${params.toString()}`);
}

async function handleFetchFocusAnalysis({ threadId = "" } = {}) {
  const trimmedThreadId = typeof threadId === "string" ? threadId.trim() : "";
  if (!trimmedThreadId) {
    throw new Error("A Gmail thread id is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  const path = `/api/google-workspace-admin/gmail-threads/${encodeURIComponent(trimmedThreadId)}/analysis`;
  const ownerUserId = getRequiredStoredOwnerUserId(stored);
  const params = new URLSearchParams({ owner_user_id: ownerUserId });
  const existing = await fetchAuthorizedPortalJson(`${path}?${params.toString()}`, { allowNotFound: true });

  if (existing) {
    return existing;
  }

  return fetchAuthorizedPortalJson(`${path.replace(/\/analysis$/, "/analyze")}`, {
    method: "POST",
    body: { owner_user_id: ownerUserId, force: false },
  });
}

async function handleFetchFocusContactAnalysis({ email = "" } = {}) {
  const normalizedEmail = typeof email === "string" ? email.trim().toLowerCase() : "";
  if (!normalizedEmail || !normalizedEmail.includes("@")) {
    throw new Error("A contact email is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  const contactPath = `/api/google-workspace-admin/contacts/${encodeURIComponent(normalizedEmail)}`;
  const ownerUserId = getRequiredStoredOwnerUserId(stored);
  const params = new URLSearchParams({ owner_user_id: ownerUserId });
  const existing = await fetchAuthorizedPortalJson(`${contactPath}/analysis?${params.toString()}`, { allowNotFound: true });

  if (existing) {
    return existing;
  }

  return fetchAuthorizedPortalJson(`${contactPath}/analyze`, {
    method: "POST",
    body: { owner_user_id: ownerUserId, force: false },
  });
}

async function handleStreakPipelines() {
  const { stored } = await getAuthorizedPortalRequestContext();
  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/streak/pipelines`);
}

async function handleStreakBoxes({ pipelineKey = "", page = 0, limit = 50 } = {}) {
  const trimmedPipelineKey = typeof pipelineKey === "string" ? pipelineKey.trim() : "";
  if (!trimmedPipelineKey) {
    throw new Error("Pipeline key is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  const params = new URLSearchParams({
    page: String(page),
    limit: String(limit),
  });
  return fetchAuthorizedPortalJson(
    `/api/organizations/${getRequiredStoredOwnerUserId(stored)}/streak/pipelines/${encodeURIComponent(trimmedPipelineKey)}/boxes?${params.toString()}`,
  );
}

async function handleStreakComment({ boxKey = "", message = "" } = {}) {
  const trimmedBoxKey = typeof boxKey === "string" ? boxKey.trim() : "";
  const trimmedMessage = typeof message === "string" ? message.trim() : "";
  if (!trimmedBoxKey) {
    throw new Error("Box key is required.");
  }
  if (!trimmedMessage) {
    throw new Error("Comment message is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/streak/boxes/${encodeURIComponent(trimmedBoxKey)}/comments`, {
    method: "POST",
    body: { message: trimmedMessage },
  });
}

async function handleStreakContactLookup({ email = "" } = {}) {
  const trimmedEmail = typeof email === "string" ? email.trim() : "";
  if (!trimmedEmail || !trimmedEmail.includes("@")) {
    throw new Error("A valid email is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  const params = new URLSearchParams({ email: trimmedEmail });
  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/streak/contacts/lookup?${params.toString()}`);
}

async function handleStreakTeams() {
  const { stored } = await getAuthorizedPortalRequestContext();
  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/streak/teams`);
}

async function handleStreakContactCreate({ email = "", teamKey = "", name = "", givenName = "", familyName = "" } = {}) {
  const trimmedEmail = typeof email === "string" ? email.trim() : "";
  const trimmedTeamKey = typeof teamKey === "string" ? teamKey.trim() : "";
  if (!trimmedEmail || !trimmedEmail.includes("@")) {
    throw new Error("A valid email is required.");
  }
  if (!trimmedTeamKey) {
    throw new Error("Team key is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/streak/contacts`, {
    method: "POST",
    body: {
      email: trimmedEmail,
      teamKey: trimmedTeamKey,
      ...(typeof name === "string" && name.trim() ? { name: name.trim() } : {}),
      ...(typeof givenName === "string" && givenName.trim() ? { givenName: givenName.trim() } : {}),
      ...(typeof familyName === "string" && familyName.trim() ? { familyName: familyName.trim() } : {}),
    },
  });
}

const extractTranscriptTextFromPayload = (value) => {
  if (!value || typeof value !== "object") {
    return "";
  }

  const root = value;
  const maybeTextFields = [
    "transcript",
    "transcript_text",
    "text",
    "content",
    "markdown",
    "transcript_markdown",
    "transcriptMarkdown",
    "transcriptText",
  ];

  const extractFromArray = (arr) => {
    const parts = [];
    for (const item of arr) {
      if (typeof item === "string" && item.trim()) {
        parts.push(item.trim());
        continue;
      }
      if (item && typeof item === "object") {
        for (const field of maybeTextFields) {
          const found = item[field];
          if (typeof found === "string" && found.trim()) {
            parts.push(found.trim());
            break;
          }
        }
      }
    }
    return parts.join("\n").trim();
  };

  for (const field of maybeTextFields) {
    const found = root[field];
    if (typeof found === "string" && found.trim()) {
      return found.trim();
    }
    if (Array.isArray(found)) {
      const extracted = extractFromArray(found);
      if (extracted) {
        return extracted;
      }
    }
  }

  if (root.result && typeof root.result === "object") {
    return extractTranscriptTextFromPayload(root.result);
  }

  return "";
};

async function handleJobTranscript({ processingId = "" } = {}) {
  const trimmedProcessingId = typeof processingId === "string" ? processingId.trim() : "";
  if (!trimmedProcessingId) {
    throw new Error("Processing id is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  const params = new URLSearchParams({ processing_id: trimmedProcessingId });
  const data = await fetchAuthorizedPortalJson(
    `/api/organizations/${getRequiredStoredOwnerUserId(stored)}/organizational-intelligence/transcript/content?${params.toString()}`,
  );
  const transcript = extractTranscriptTextFromPayload(data);
  if (!transcript) {
    throw new Error("No transcript available for this meeting.");
  }

  return { transcript };
}

/** Open a Portal app path in a new tab (same origin as configured appUrl). */
async function handleOpenPortalPath({ path = "/" } = {}) {
  if (typeof path !== "string" || !path.startsWith("/") || path.startsWith("//")) {
    throw new Error("Invalid Portal path.");
  }

  const appUrl = (await getAppUrl()).replace(/\/+$/, "");
  const url = `${appUrl}${path}`;
  const tab = await chrome.tabs.create({ url });
  return { tabId: tab.id, url };
}

async function handlePersonDetails({ email = "", personId = "" } = {}) {
  const trimmedEmail = typeof email === "string" ? email.trim() : "";
  const trimmedPersonId = typeof personId === "string" ? personId.trim() : "";
  if (!trimmedEmail && !trimmedPersonId) {
    throw new Error("Email or person id is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/organizational-intelligence/persons/details`, {
    method: "POST",
    body: trimmedPersonId ? { person_id: trimmedPersonId } : { email: trimmedEmail },
  });
}

async function handleWikiPages({ query = "", type = "", limit = 20, offset = 0 } = {}) {
  const { stored } = await getAuthorizedPortalRequestContext();
  const params = new URLSearchParams({
    limit: String(limit),
    offset: String(offset),
  });
  const trimmedQuery = typeof query === "string" ? query.trim() : "";
  const trimmedType = typeof type === "string" ? type.trim() : "";
  if (trimmedQuery) {
    params.set("query", trimmedQuery);
  }
  if (trimmedType) {
    params.set("type", trimmedType);
  }

  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/wiki/pages?${params.toString()}`);
}

async function handleWikiPage({ pageId = "" } = {}) {
  const trimmedPageId = typeof pageId === "string" ? pageId.trim() : "";
  if (!trimmedPageId) {
    throw new Error("Wiki page id is required.");
  }

  const { stored } = await getAuthorizedPortalRequestContext();
  return fetchAuthorizedPortalJson(`/api/organizations/${getRequiredStoredOwnerUserId(stored)}/wiki/pages/${encodeURIComponent(trimmedPageId)}`);
}

let devReloadSocket = null;
let devReloadReconnectTimer = null;
let devReloadConnectInFlight = null;

function connectDevReloadSocket() {
  if (!IS_LOCAL_PROOF_EXTENSION || devReloadSocket || devReloadConnectInFlight) {
    return;
  }

  devReloadConnectInFlight = connectDevReloadSocketWhenServerIsReady()
    .catch(() => {
      devReloadSocket = null;
    })
    .finally(() => {
      devReloadConnectInFlight = null;
    });
}

async function connectDevReloadSocketWhenServerIsReady() {
  const isAvailable = await isDevReloadServerAvailable();
  if (!isAvailable || devReloadSocket) {
    return;
  }

  try {
    const socket = new WebSocket(DEV_RELOAD_WS_URL);
    devReloadSocket = socket;

    socket.addEventListener("message", (event) => {
      let payload;

      try {
        payload = JSON.parse(String(event.data));
      } catch {
        payload = { type: String(event.data) };
      }

      if (payload?.type === "reload") {
        void handleDevReloadRequest();
      }
    });

    socket.addEventListener("close", () => {
      if (devReloadSocket === socket) {
        devReloadSocket = null;
      }
      scheduleDevReloadReconnect();
    });

    socket.addEventListener("error", () => {
      socket.close();
    });
  } catch {
    devReloadSocket = null;
    scheduleDevReloadReconnect();
  }
}

async function isDevReloadServerAvailable() {
  const abortController = new AbortController();
  const timeoutId = setTimeout(() => abortController.abort(), 500);

  try {
    const response = await fetch(DEV_RELOAD_HEALTH_URL, {
      cache: "no-store",
      signal: abortController.signal,
    });
    return response.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timeoutId);
  }
}

function scheduleDevReloadReconnect() {
  if (!IS_LOCAL_PROOF_EXTENSION || devReloadReconnectTimer) {
    return;
  }

  devReloadReconnectTimer = setTimeout(() => {
    devReloadReconnectTimer = null;
    connectDevReloadSocket();
  }, 2000);
}

async function handleDevReloadRequest() {
  await chrome.storage.local.set({ [DEV_RELOAD_REQUESTED_AT_KEY]: Date.now() });
  chrome.runtime.reload();
}

async function reloadGmailTabsAfterDevReload() {
  const stored = await chrome.storage.local.get([DEV_RELOAD_REQUESTED_AT_KEY]);
  const requestedAt = Number(stored[DEV_RELOAD_REQUESTED_AT_KEY] ?? 0);
  if (!Number.isFinite(requestedAt) || Date.now() - requestedAt > 30000) {
    return;
  }

  await chrome.storage.local.remove([DEV_RELOAD_REQUESTED_AT_KEY]);
  const tabs = await chrome.tabs.query({ url: GMAIL_URL_PATTERN });

  await Promise.all(
    tabs
      .map((tab) => tab.id)
      .filter((tabId) => typeof tabId === "number")
      .map((tabId) => chrome.tabs.reload(tabId)),
  );
}

connectDevReloadSocket();
void reloadGmailTabsAfterDevReload();
