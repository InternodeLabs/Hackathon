(() => {
  const fixtureConversations = [
    {
      id: "q3-enterprise-pricing",
      section: "Today",
      subject: "Q3 Enterprise Pricing Overhaul",
      contributors: "Sean Shadmand, Istvan Lorincz, me",
      participantNames: ["Sean Shadmand", "Istvan Lorincz", "me", "Mara Velden", "Tom Eriksen", "Priya Nair", "Lucas Bauer", "Sofia Mendes"],
      messageCount: 14,
      lastActivity: "Today, 6:40 PM",
      activityLabel: "Active today",
      preview: "Sean: Looks good. Let's lock this in before EOD and loop in legal.",
      highlight: "The group agreed to send the final contract to legal by Monday",
      highlightSource: "\"Let's lock this in before EOD and loop in legal — Sean will send the final version Monday AM.\" — Q3 pricing thread",
      summary:
        "The thread has been focused on finalising a new enterprise pricing model for Internode, with the group aligning on a tiered " +
        "structure designed to accelerate Scale Enterprise adoption. Sean proposed locking the model before end of week, Istvan flagged " +
        "two open items around procurement compliance, and the group agreed legal review should happen in parallel before the Monday deadline.",
      messages: [
        { subject: "Re: Final pricing deck attached", author: "Sean Shadmand", replies: 14, time: "Today, 6:40 PM" },
        { subject: "Contract draft v2 — please review", author: "Istvan Lorincz", replies: 8, time: "Yesterday, 3:10 PM" },
        { subject: "Kickoff call notes & next steps", author: "me", replies: 5, time: "Mon, 11:05 AM" },
        { subject: "Fwd: Legal sign-off required", author: "Eva Gyori", replies: 2, time: "Mon, 9:20 AM" },
        { subject: "Initial intro — Q3 pricing thread", author: "Jay Levy", replies: 22, time: "Last week" },
      ],
    },
    {
      id: "onboarding-flow",
      section: "Today",
      subject: "Onboarding Flow Redesign Kickoff",
      contributors: "Adam Smith, me, Judit K.",
      participantNames: ["Adam Smith", "me", "Judit K.", "Mara Velden"],
      messageCount: 8,
      lastActivity: "Today, 4:20 PM",
      activityLabel: "Active today",
      preview: "me: I've attached the revised screens — let me know if step 3 copy works.",
      highlight: "",
      highlightSource: "",
      summary: "",
      messages: [],
    },
    {
      id: "monday-contract",
      section: "Today",
      subject: "Monday Contract Review",
      contributors: "me, Eva Gyori",
      participantNames: ["me", "Eva Gyori", "Sean Shadmand"],
      messageCount: 5,
      lastActivity: "Today, 2:21 AM",
      activityLabel: "Active today",
      preview: "Eva: Can we move this to 10am? I have a conflict at 9.",
      highlight: "",
      highlightSource: "",
      summary: "",
      messages: [],
    },
    {
      id: "sales-role-play",
      section: "This week",
      subject: "Daily Sales Role-Play: Data Tracing & Evaluations",
      contributors: "Sean Shadmand, Mariya E., me, +4",
      participantNames: ["Sean Shadmand", "Mariya E.", "me", "Eva Gyori", "Priya Nair"],
      messageCount: 22,
      lastActivity: "Yesterday, 2:21 AM",
      activityLabel: "Active yesterday",
      preview: "Mariya: Great session everyone. Recording is in the shared drive.",
      highlight: "",
      highlightSource: "",
      summary: "",
      messages: [],
    },
  ];

  const styles = `
    :host { color: #151515; font-family: Arial, Helvetica, sans-serif; }
    .focus-root { display: flex; flex: 1 1 auto; min-width: 0; width: 100%; }
    .focus-page {
      align-self: stretch; background: #fff; box-sizing: border-box; flex: 1 1 auto; min-height: 100%; overflow: auto;
      padding: 34px 48px 52px; width: 100%;
    }
    .focus-page-inner { margin: 0 auto; max-width: 768px; }
    .focus-heading-row { align-items: start; display: flex; gap: 24px; justify-content: space-between; }
    .focus-title { font-size: 25px; font-weight: 700; letter-spacing: -0.03em; line-height: 1.15; margin: 0; }
    .focus-subtitle, .focus-muted { color: #8a8a8a; font-size: 14px; line-height: 1.4; margin: 5px 0 0; }
    .focus-activity { color: #777; font-size: 14px; padding-top: 2px; white-space: nowrap; }
    .focus-section { color: #969696; font-size: 13px; margin: 32px 0 12px; }
    .focus-list { display: flex; flex-direction: column; gap: 9px; }
    .focus-conversation {
      align-items: center; background: #fff; border: 1px solid #dedede; border-radius: 10px; cursor: pointer; display: grid;
      gap: 14px; grid-template-columns: 44px minmax(0, 1fr) auto; min-height: 78px; padding: 0 16px; text-align: left; width: 100%;
    }
    .focus-conversation:hover { background: #f7f7f7; border-color: #cfcfcf; }
    .focus-conversation-primary { background: #f3f3f3; }
    .focus-thread-icon { height: 32px; position: relative; width: 36px; }
    .focus-thread-icon::before, .focus-thread-icon::after {
      border: 1px solid #b6b6b6; border-radius: 50%; content: \"\"; height: 24px; position: absolute; width: 24px;
    }
    .focus-thread-icon::before { left: 1px; top: 0; }
    .focus-thread-icon::after { bottom: 0; right: 0; }
    .focus-conversation-copy { min-width: 0; }
    .focus-subject {
      color: #111; font-size: 15px; font-weight: 600; line-height: 1.3; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .focus-contributors, .focus-preview {
      color: #858585; font-size: 13px; line-height: 1.35; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .focus-preview { margin-top: 3px; }
    .focus-conversation-meta { align-items: center; color: #8a8a8a; display: flex; font-size: 12px; gap: 19px; white-space: nowrap; }
    .focus-count { color: #a0a0a0; font-size: 10px; }
    .focus-loading { color: #aaa; font-size: 13px; padding: 42px 0 0; text-align: center; }
    .focus-back { background: transparent; border: 0; color: #555; cursor: pointer; font: inherit; font-size: 13px; margin: 0 0 25px; padding: 0; }
    .focus-back:hover { color: #111; text-decoration: none; }
    .focus-pills { display: flex; flex-wrap: wrap; gap: 8px; margin: 18px 0 32px; }
    .focus-pill {
      background: #fff; border: 1px solid #d3d3d3; border-radius: 999px; color: #171717; cursor: pointer; font: inherit;
      font-size: 13px; padding: 7px 14px;
    }
    .focus-pill:hover { background: #f5f5f5; }
    .focus-detail-section { margin-top: 32px; }
    .focus-detail-heading { font-size: 17px; font-weight: 700; margin: 0; }
    .focus-detail-copy { color: #999; font-size: 13px; margin: 6px 0 13px; }
    .focus-highlight { border: 1px solid #dedede; border-radius: 9px; padding: 14px 16px; }
    .focus-highlight + .focus-highlight { margin-top: 8px; }
    .focus-highlight-copy { font-size: 15px; line-height: 1.4; }
    .focus-highlight-source { color: #aaa; font-size: 12px; font-style: italic; line-height: 1.4; margin-top: 6px; }
    .focus-highlight-toggle {
      background: transparent; border: 0; color: #1a73e8; cursor: pointer; font: inherit; font-size: 14px; font-weight: 500;
      margin-top: 12px; padding: 4px 0;
    }
    .focus-highlight-toggle:hover { text-decoration: underline; }
    .focus-summary { background: #f2f2f2; border-radius: 16px; padding: 23px 24px; }
    .focus-summary-heading { font-size: 16px; font-weight: 700; margin: 0; }
    .focus-summary-copy { color: #444; font-size: 15px; line-height: 1.55; margin: 18px 0 0; }
    .focus-message-list { margin-top: 18px; }
    .focus-message {
      align-items: center; background: transparent; border: 0; border-bottom: 1px solid #e1e1e1; cursor: pointer; display: grid;
      font: inherit; gap: 14px; grid-template-columns: 32px minmax(0, 1fr) auto; min-height: 64px; padding: 0 8px; text-align: left;
      width: 100%;
    }
    .focus-message:hover { background: #f7f7f7; }
    .focus-message-icon { border: 1px solid #d1d1d1; border-radius: 9px; height: 30px; width: 30px; }
    .focus-message-subject { color: #222; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .focus-message-author, .focus-message-time { color: #929292; font-size: 12px; margin-top: 3px; }
    .focus-message-time { margin: 0; white-space: nowrap; }
    @media (max-width: 720px) { .focus-page { padding: 28px 24px 40px; } .focus-conversation-meta { gap: 10px; } }
  `;

  const appendText = (parent, tagName, className, value) => {
    const element = document.createElement(tagName);
    if (className) element.className = className;
    element.textContent = value;
    parent.appendChild(element);
    return element;
  };

  const clearElement = (element) => element.replaceChildren();

  const formatActivity = (value) => {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value || "Recently";

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfYesterday = new Date(startOfToday);
    startOfYesterday.setDate(startOfYesterday.getDate() - 1);
    const time = date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

    if (date >= startOfToday) return `Today, ${time}`;
    if (date >= startOfYesterday) return `Yesterday, ${time}`;
    if (now.getTime() - date.getTime() < 7 * 24 * 60 * 60 * 1000) {
      return `${date.toLocaleDateString([], { weekday: "short" })}, ${time}`;
    }

    return date.toLocaleDateString([], { month: "short", day: "numeric" });
  };

  const getConversationSection = (value) => {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "Earlier";

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    return date >= startOfToday ? "Today" : "This week";
  };

  const normalizeConversation = (conversation) => {
    const contributorNames = Array.isArray(conversation?.contributorNames) ? conversation.contributorNames : [];
    const rawParticipants = Array.isArray(conversation?.participants) ? conversation.participants : [];
    const participants = rawParticipants
      .map((participant) => {
        const email = typeof participant?.email === "string" ? participant.email.trim().toLowerCase() : "";
        const name = typeof participant?.name === "string" ? participant.name.trim() : "";
        return email ? { email, name: name || email } : null;
      })
      .filter(Boolean);
    const participantNames = participants.length > 0
      ? participants.map((participant) => participant.name)
      : Array.isArray(conversation?.participantNames)
        ? conversation.participantNames
        : [];
    const messages = Array.isArray(conversation?.messages) ? conversation.messages : [];
    const lastActivity = typeof conversation?.lastActivity === "string" ? conversation.lastActivity : "";

    return {
      id: conversation?.id || crypto.randomUUID(),
      section: getConversationSection(lastActivity),
      subject: conversation?.subject || "(no subject)",
      contributors: contributorNames.join(", ") || "Participants unavailable",
      participantNames,
      participants: participants.length > 0 ? participants : participantNames.map((name) => ({ email: "", name })),
      messageCount: Number.isFinite(conversation?.messageCount) ? conversation.messageCount : messages.length,
      lastActivity: formatActivity(lastActivity),
      activityLabel: lastActivity && new Date(lastActivity) >= new Date(new Date().setHours(0, 0, 0, 0)) ? "Active today" : "Active recently",
      preview: conversation?.preview || "",
      highlight: "",
      highlightSource: "",
      summary: "",
      messages: messages.map((message) => ({
        subject: message?.subject || conversation?.subject || "(no subject)",
        author: message?.author || "Unknown sender",
        replies: "",
        time: formatActivity(message?.date || ""),
      })),
    };
  };

  const createThreadIcon = () => {
    const icon = document.createElement("span");
    icon.className = "focus-thread-icon";
    return icon;
  };

  const openGmailThread = (threadId) => {
    if (typeof threadId !== "string" || !threadId) return;
    window.dispatchEvent(
      new CustomEvent("klear-open-gmail-thread", {
        detail: { threadId },
      }),
    );
  };

  const renderConversationCard = (conversation, onSelect, { primary = false } = {}) => {
    const card = document.createElement("button");
    card.type = "button";
    card.className = `focus-conversation${primary ? " focus-conversation-primary" : ""}`;
    card.appendChild(createThreadIcon());

    const copy = document.createElement("div");
    copy.className = "focus-conversation-copy";
    appendText(copy, "div", "focus-subject", conversation.subject);
    appendText(copy, "div", "focus-contributors", conversation.contributors);
    appendText(copy, "div", "focus-preview", conversation.preview);
    card.appendChild(copy);

    const meta = document.createElement("div");
    meta.className = "focus-conversation-meta";
    appendText(meta, "span", "focus-count", String(conversation.messageCount));
    appendText(meta, "span", "", conversation.lastActivity);
    card.appendChild(meta);
    card.addEventListener("click", () => onSelect(conversation));
    return card;
  };

  const renderHome = (container, displayedConversations, onSelect) => {
    clearElement(container);
    const page = document.createElement("main");
    page.className = "focus-page";
    const inner = document.createElement("div");
    inner.className = "focus-page-inner";
    page.appendChild(inner);

    appendText(inner, "h1", "focus-title", "Conversations you interacted with");
    appendText(inner, "p", "focus-subtitle", "Conversations you are part of recently");

    if (displayedConversations.length === 0) {
      appendText(inner, "p", "focus-muted", "No conversations you participated in were found.");
    }

    for (const section of ["Today", "This week", "Earlier"]) {
      const sectionConversations = displayedConversations.filter((conversation) => conversation.section === section);
      if (sectionConversations.length === 0) continue;
      appendText(inner, "div", "focus-section", section);
      const list = document.createElement("div");
      list.className = "focus-list";
      sectionConversations.forEach((conversation, index) => {
        list.appendChild(renderConversationCard(conversation, onSelect, { primary: section === "Today" && index === 0 }));
      });
      inner.appendChild(list);
    }

    container.appendChild(page);
  };

  const getContactProfile = (participant) => {
    const name = typeof participant?.name === "string" ? participant.name : "";
    const email = typeof participant?.email === "string" ? participant.email : "";
    const profiles = {
      "Sean Shadmand": { email: "sean@internode.ai", role: "President of Internode" },
      "Istvan Lorincz": { email: "istvan@internode.ai", role: "Internode" },
      "Mara Velden": { email: "mara@internode.ai", role: "Internode" },
      "Tom Eriksen": { email: "tom@internode.ai", role: "Internode" },
      "Priya Nair": { email: "priya@internode.ai", role: "Internode" },
      "Lucas Bauer": { email: "lucas@internode.ai", role: "Internode" },
      "Sofia Mendes": { email: "sofia@internode.ai", role: "Internode" },
    };
    const profile = profiles[name] ?? { email: "", role: "Contact" };
    return { name: name || email || "Contact", email: email || profile.email, role: profile.role };
  };

  const formatCommitment = (commitment) => {
    const fromParty = commitment?.from_party || "Someone";
    const toParty = commitment?.to_party || "someone";
    const deliverable = commitment?.deliverable || "complete the requested work";

    if (commitment?.perspective === "receivable") {
      return `${fromParty} committed to ${deliverable} for you.`;
    }

    if (commitment?.perspective === "deliverable") {
      return `You committed to ${deliverable} for ${toParty}.`;
    }

    return `${fromParty} committed to ${deliverable} for ${toParty}.`;
  };

  const formatCommitmentSource = (commitment) => {
    const originDate = typeof commitment?.origin_date === "string" ? new Date(commitment.origin_date) : null;
    if (!originDate || Number.isNaN(originDate.getTime())) {
      return "Commitment identified in this thread";
    }

    return `Commitment identified on ${originDate.toLocaleDateString([], { month: "short", day: "numeric" })}`;
  };

  const sortCommitmentsNewestFirst = (commitments) =>
    [...commitments].sort((left, right) => {
      const leftDate = new Date(left?.origin_date ?? "").getTime();
      const rightDate = new Date(right?.origin_date ?? "").getTime();
      const leftTimestamp = Number.isNaN(leftDate) ? -Infinity : leftDate;
      const rightTimestamp = Number.isNaN(rightDate) ? -Infinity : rightDate;
      return rightTimestamp - leftTimestamp;
    });

  const HIGHLIGHT_PREVIEW_LIMIT = 3;

  const appendCommitmentHighlights = (section, commitments) => {
    const list = document.createElement("div");
    section.appendChild(list);
    let isExpanded = false;

    const render = () => {
      clearElement(list);
      const visibleCommitments = isExpanded ? commitments : commitments.slice(0, HIGHLIGHT_PREVIEW_LIMIT);
      visibleCommitments.forEach((commitment) => {
        const highlight = document.createElement("div");
        highlight.className = "focus-highlight";
        appendText(highlight, "div", "focus-highlight-copy", formatCommitment(commitment));
        appendText(highlight, "div", "focus-highlight-source", formatCommitmentSource(commitment));
        list.appendChild(highlight);
      });
    };

    render();

    if (commitments.length <= HIGHLIGHT_PREVIEW_LIMIT) {
      return;
    }

    const toggle = appendText(section, "button", "focus-highlight-toggle", "Show more");
    toggle.type = "button";
    toggle.setAttribute("aria-expanded", "false");
    toggle.addEventListener("click", () => {
      isExpanded = !isExpanded;
      toggle.textContent = isExpanded ? "Show less" : "Show more";
      toggle.setAttribute("aria-expanded", String(isExpanded));
      render();
    });
  };

  const renderDetail = (container, conversation, analysis, analysisError, onBack, onSelectContact) => {
    clearElement(container);
    const page = document.createElement("main");
    page.className = "focus-page";
    const inner = document.createElement("div");
    inner.className = "focus-page-inner";
    page.appendChild(inner);

    const back = appendText(inner, "button", "focus-back", "← Conversations");
    back.type = "button";
    back.addEventListener("click", onBack);

    const heading = document.createElement("div");
    heading.className = "focus-heading-row";
    appendText(heading, "h1", "focus-title", conversation.subject);
    appendText(heading, "div", "focus-activity", conversation.activityLabel);
    inner.appendChild(heading);
    appendText(inner, "p", "focus-subtitle", `${conversation.contributors} · ${conversation.messageCount} messages`);

    const pills = document.createElement("div");
    pills.className = "focus-pills";
    conversation.participants.forEach((participant) => {
      const pill = appendText(pills, "button", "focus-pill", participant.name);
      pill.type = "button";
      pill.addEventListener("click", () => onSelectContact(getContactProfile(participant)));
    });
    inner.appendChild(pills);

    const highlights = document.createElement("section");
    highlights.className = "focus-detail-section";
    appendText(highlights, "h2", "focus-detail-heading", "Highlights");
    appendText(highlights, "p", "focus-detail-copy", "Key actions surfaced from this thread");
    const commitments = Array.isArray(analysis?.commitments) ? sortCommitmentsNewestFirst(analysis.commitments) : [];
    if (commitments.length > 0) {
      appendCommitmentHighlights(highlights, commitments);
    } else if (conversation.highlight) {
      const highlight = document.createElement("div");
      highlight.className = "focus-highlight";
      appendText(highlight, "div", "focus-highlight-copy", conversation.highlight);
      appendText(highlight, "div", "focus-highlight-source", conversation.highlightSource);
      highlights.appendChild(highlight);
    } else {
      appendText(highlights, "div", "focus-highlight", analysisError ?? "No open commitments were found in this thread.");
    }
    inner.appendChild(highlights);

    const summary = document.createElement("section");
    summary.className = "focus-detail-section focus-summary";
    appendText(summary, "h2", "focus-summary-heading", "Catch up");
    appendText(summary, "p", "focus-detail-copy", "What this group has been discussing");
    appendText(
      summary,
      "p",
      "focus-summary-copy",
      analysis?.summary || conversation.summary || analysisError || "A thread summary will appear here once it is available.",
    );
    inner.appendChild(summary);

    const messages = document.createElement("section");
    messages.className = "focus-detail-section";
    appendText(messages, "h2", "focus-detail-heading", "Previous messages");
    appendText(messages, "p", "focus-detail-copy", "Earlier emails in this thread");
    const messageList = document.createElement("div");
    messageList.className = "focus-message-list";
    const fallbackMessage = {
      subject: conversation.subject,
      author: conversation.contributors,
      replies: conversation.messageCount,
      time: conversation.lastActivity,
    };
    const visibleMessages = conversation.messages.length > 0 ? conversation.messages : [fallbackMessage];
    visibleMessages.forEach((message) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "focus-message";
      row.setAttribute("aria-label", `Open ${message.subject} in Gmail`);
      row.addEventListener("click", () => openGmailThread(conversation.id));
      const icon = document.createElement("span");
      icon.className = "focus-message-icon";
      row.appendChild(icon);
      const copy = document.createElement("div");
      appendText(copy, "div", "focus-message-subject", message.subject);
      const replies = message.replies === "" ? "" : ` · ${message.replies} replies`;
      appendText(copy, "div", "focus-message-author", `${message.author}${replies}`);
      row.appendChild(copy);
      appendText(row, "div", "focus-message-time", message.time);
      messageList.appendChild(row);
    });
    messages.appendChild(messageList);
    inner.appendChild(messages);
    container.appendChild(page);
  };

  const renderContact = (container, contact, conversation, analysis, analysisError, onBack) => {
    clearElement(container);
    const page = document.createElement("main");
    page.className = "focus-page";
    const inner = document.createElement("div");
    inner.className = "focus-page-inner";
    page.appendChild(inner);

    const back = appendText(inner, "button", "focus-back", "← Conversation");
    back.type = "button";
    back.addEventListener("click", onBack);

    const heading = document.createElement("div");
    heading.className = "focus-heading-row";
    appendText(heading, "h1", "focus-title", contact.name);
    appendText(heading, "div", "focus-activity", contact.email);
    inner.appendChild(heading);
    appendText(inner, "p", "focus-subtitle", contact.role);

    const highlights = document.createElement("section");
    highlights.className = "focus-detail-section";
    appendText(highlights, "h2", "focus-detail-heading", "Highlights");
    appendText(highlights, "p", "focus-detail-copy", `Highlighted actions from recent interactions with ${contact.name}`);
    const commitments = Array.isArray(analysis?.commitments) ? sortCommitmentsNewestFirst(analysis.commitments) : [];
    if (commitments.length > 0) {
      appendCommitmentHighlights(highlights, commitments);
    } else {
      appendText(highlights, "div", "focus-highlight", analysisError ?? "No open commitments were found with this contact.");
    }
    inner.appendChild(highlights);

    const summary = document.createElement("section");
    summary.className = "focus-detail-section focus-summary";
    appendText(summary, "h2", "focus-summary-heading", "Catch up");
    appendText(summary, "p", "focus-detail-copy", `What happened between you and ${contact.name}`);
    appendText(summary, "p", "focus-summary-copy", analysis?.summary || analysisError || "No analyzed conversations with this contact yet.");
    inner.appendChild(summary);

    const interactions = document.createElement("section");
    interactions.className = "focus-detail-section";
    appendText(interactions, "h2", "focus-detail-heading", "Messages in this thread");
    appendText(interactions, "p", "focus-detail-copy", `Messages in ${conversation.subject}`);
    const list = document.createElement("div");
    list.className = "focus-message-list";
    const rows = conversation.messages.length > 0 ? conversation.messages.slice(0, 4) : [
      { subject: conversation.subject, author: contact.name, replies: conversation.messageCount, time: conversation.lastActivity },
    ];
    rows.forEach((message) => {
      const row = document.createElement("div");
      row.className = "focus-message";
      const icon = document.createElement("span");
      icon.className = "focus-message-icon";
      row.appendChild(icon);
      const copy = document.createElement("div");
      appendText(copy, "div", "focus-message-subject", message.subject);
      const replies = message.replies === "" ? "" : `${message.replies} replies`;
      appendText(copy, "div", "focus-message-author", replies);
      row.appendChild(copy);
      appendText(row, "div", "focus-message-time", message.time);
      list.appendChild(row);
    });
    interactions.appendChild(list);
    inner.appendChild(interactions);
    container.appendChild(page);
  };

  window.KlearFocusConversations = {
    render(
      container,
      payload = null,
      { route = {}, analysis = null, analysisError = null, contactAnalysis = null, contactAnalysisError = null, onNavigate = null } = {},
    ) {
      const style = document.createElement("style");
      style.textContent = styles;
      container.replaceChildren(style);
      const content = document.createElement("div");
      content.className = "focus-root";
      container.appendChild(content);
      const apiConversations = Array.isArray(payload?.conversations) ? payload.conversations.map(normalizeConversation) : null;
      const displayedConversations = apiConversations ?? fixtureConversations;
      const navigate = (target = {}) => {
        if (typeof onNavigate === "function") {
          onNavigate(target);
        }
      };
      const showHome = () => renderHome(content, displayedConversations, (conversation) => navigate({ conversationId: conversation.id }));
      const showContact = (contact, conversation) =>
        renderContact(content, contact, conversation, contactAnalysis, contactAnalysisError, () => navigate({ conversationId: conversation.id }));
      const showDetail = (conversation) =>
        renderDetail(
          content,
          conversation,
          analysis,
          analysisError,
          () => navigate(),
          (contact) => navigate({ contactName: contact.name, conversationId: conversation.id }),
        );

      const selectedConversation = displayedConversations.find((conversation) => conversation.id === route.conversationId) ?? null;
      if (!selectedConversation) {
        showHome();
        return;
      }

      if (typeof route.contactName === "string" && route.contactName) {
        const selectedParticipant = selectedConversation.participants.find((participant) => participant.name === route.contactName) ?? {
          email: route.contactName.includes("@") ? route.contactName : "",
          name: route.contactName,
        };
        showContact(getContactProfile(selectedParticipant), selectedConversation);
        return;
      }

      showDetail(selectedConversation);
    },
  };
})();
