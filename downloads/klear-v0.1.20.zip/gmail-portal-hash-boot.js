/**
 * MAIN-world, document_start.
 *
 * Gmail rewrites unknown hashes to `#inbox` via its own history.replaceState.
 * Isolated-world content scripts cannot patch that. This script runs in the page
 * JS world before Gmail and:
 *  1) reads a sticky `#portal/...` hash from sessionStorage (set on the previous
 *     page via pagehide / while Insights is open)
 *  2) monkey-patches history.pushState / replaceState so Gmail cannot clear it
 *     during the boot window
 *  3) stops as soon as sticky is cleared (user left Insights)
 */
(() => {
  const PORTAL_INSIGHTS_HASH_RE =
    /^#klear\/insights(?:\/(?:meeting\/[^/?#]+|person\/[^/?#]+|conversation\/[^/?#]+|contact\/[^/?#]+\/[^/?#]+))?\/?$/;
  const STICKY_HASH_KEY = "klear-gmail-sticky-hash";
  const LOCK_MS = 15000;

  const readSticky = () => {
    try {
      const hash = sessionStorage.getItem(STICKY_HASH_KEY);
      return typeof hash === "string" && PORTAL_INSIGHTS_HASH_RE.test(hash) ? hash : null;
    } catch {
      return null;
    }
  };

  const writeSticky = (hash) => {
    try {
      sessionStorage.setItem(STICKY_HASH_KEY, hash);
    } catch {
      // ignore
    }
  };

  if (PORTAL_INSIGHTS_HASH_RE.test(window.location.hash)) {
    writeSticky(window.location.hash);
  }

  if (!readSticky()) {
    return;
  }

  let lockUntil = Date.now() + LOCK_MS;

  const enforce = () => {
    if (Date.now() > lockUntil) {
      return false;
    }

    // User left Insights — isolated world cleared sticky; stop fighting.
    const stickyHash = readSticky();
    if (!stickyHash) {
      return false;
    }

    if (window.location.hash === stickyHash) {
      return true;
    }

    try {
      history.replaceState(history.state, "", `${window.location.pathname}${window.location.search}${stickyHash}`);
    } catch {
      // ignore
    }
    return window.location.hash === stickyHash;
  };

  const armPortalRoute = (hash) => {
    if (!PORTAL_INSIGHTS_HASH_RE.test(hash)) {
      return;
    }

    // Browser Back restores the Focus URL before the isolated content script can
    // run. Gmail immediately treats that custom route as Inbox, so preserve it in
    // MAIN world first and briefly guard the return route from Gmail's rewrite.
    writeSticky(hash);
    lockUntil = Date.now() + LOCK_MS;
    enforce();
  };

  const wrapHistoryMethod = (original) =>
    function portalPatchedHistoryMethod(state, title, url) {
      const result = original.call(this, state, title, url);
      if (Date.now() <= lockUntil) {
        enforce();
      }
      return result;
    };

  try {
    history.pushState = wrapHistoryMethod(history.pushState.bind(history));
    history.replaceState = wrapHistoryMethod(history.replaceState.bind(history));
  } catch {
    // ignore — still poll below
  }

  window.addEventListener(
    "hashchange",
    () => {
      armPortalRoute(window.location.hash);
      if (Date.now() <= lockUntil) {
        enforce();
      }
    },
    true,
  );

  window.addEventListener(
    "popstate",
    () => {
      if (PORTAL_INSIGHTS_HASH_RE.test(window.location.hash)) {
        armPortalRoute(window.location.hash);
        return;
      }

      // A Back/Forward navigation away from Focus is intentional. This must
      // happen in MAIN world before Gmail can turn it into another hash rewrite.
      try {
        sessionStorage.removeItem(STICKY_HASH_KEY);
      } catch {
        // ignore
      }
    },
    true,
  );

  enforce();
  const intervalId = window.setInterval(() => {
    if (!enforce()) {
      window.clearInterval(intervalId);
    }
  }, 10);
})();
