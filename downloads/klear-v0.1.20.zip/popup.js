const out = document.getElementById("out");
const meta = document.getElementById("meta");
const appUrlInput = document.getElementById("appUrl");
const workspaceField = document.getElementById("workspaceField");
const workspaceSelect = document.getElementById("workspace");
const APP_URL_STORAGE_KEY = "appUrl:app.internode.ai";
const SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY = "selectedWorkspaceOwnerUserId";

const setOut = (value) => {
  out.textContent = typeof value === "string" ? value : JSON.stringify(value, null, 2);
};

meta.textContent = `Extension ID: ${chrome.runtime.id}`;

const getWorkspaces = (user) => {
  if (!Array.isArray(user?.workspaces)) {
    return [];
  }

  return user.workspaces.filter((workspace) => typeof workspace?.ownerUserId === "string" && workspace.ownerUserId);
};

const renderWorkspaceSelector = (user, selectedOwnerUserId) => {
  const workspaces = getWorkspaces(user);
  workspaceSelect.replaceChildren();

  if (workspaces.length === 0) {
    workspaceField.hidden = true;
    return;
  }

  if (workspaces.length > 1 && !workspaces.some((workspace) => workspace.ownerUserId === selectedOwnerUserId)) {
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Choose a workspace";
    placeholder.disabled = true;
    placeholder.selected = true;
    workspaceSelect.appendChild(placeholder);
  }

  for (const workspace of workspaces) {
    const option = document.createElement("option");
    option.value = workspace.ownerUserId;
    option.textContent = typeof workspace.name === "string" && workspace.name ? workspace.name : "Untitled workspace";
    option.selected = workspace.ownerUserId === selectedOwnerUserId;
    workspaceSelect.appendChild(option);
  }

  workspaceSelect.disabled = workspaces.length === 1;
  workspaceField.hidden = false;
};

const renderStoredSession = (stored) => {
  if (stored.user?.email) {
    setOut(`Signed in as ${stored.user.email} (${stored.user.id})`);
  }
  renderWorkspaceSelector(stored.user, stored[SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]);
};

void chrome.storage.local.get([APP_URL_STORAGE_KEY, "user", SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]).then((stored) => {
  const storedAppUrl = stored[APP_URL_STORAGE_KEY];
  if (typeof storedAppUrl === "string" && storedAppUrl) {
    appUrlInput.value = storedAppUrl;
  }
  renderStoredSession(stored);
});

workspaceSelect.addEventListener("change", () => {
  const ownerUserId = workspaceSelect.value;
  if (!ownerUserId) {
    return;
  }
  void chrome.storage.local.set({ [SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]: ownerUserId }).then(() => {
    setOut("Workspace selected. Return to Gmail and choose Try again.");
  });
});

document.getElementById("saveUrl").addEventListener("click", () => {
  void chrome.storage.local.set({ [APP_URL_STORAGE_KEY]: appUrlInput.value.trim() }).then(() => {
    setOut(`Saved app URL: ${appUrlInput.value.trim()}`);
  });
});

document.getElementById("login").addEventListener("click", () => {
  setOut("Starting auth flow…");
  void chrome.runtime.sendMessage({ type: "extension-login" }).then((response) => {
    if (!response?.ok) {
      setOut(response?.error ?? "Login failed");
      return;
    }
    void chrome.storage.local.get(["user", SELECTED_WORKSPACE_OWNER_USER_ID_STORAGE_KEY]).then((stored) => {
      renderStoredSession(stored);
      const workspaces = getWorkspaces(stored.user);
      setOut(
        workspaces.length > 1
          ? "Signed in. Choose the workspace Klear should connect to."
          : "Signed in and workspace selected.",
      );
    });
  });
});

document.getElementById("jobs").addEventListener("click", () => {
  setOut("Fetching jobs…");
  void chrome.runtime.sendMessage({ type: "fetch-jobs" }).then((response) => {
    if (!response?.ok) {
      setOut(response?.error ?? "Jobs fetch failed");
      return;
    }
    setOut(response.result);
  });
});
